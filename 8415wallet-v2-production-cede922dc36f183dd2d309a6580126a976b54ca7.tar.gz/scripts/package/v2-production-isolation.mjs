/** Dependency-free production V2 static isolation check.
 * Reuses the shipped verify-auth-v2 Node parser primitives (vm.SourceTextModule),
 * so an extracted kit needs no TypeScript compiler. The original TypeScript AST
 * closure validation still runs at build/CI via v2-public-isolation.mjs.
 * Unsupported syntax is rejected by the real Node parser; dynamic imports must be
 * single string literals; every module must be reachable from the public roots.
 */
import { lstatSync, readdirSync, readFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { moduleImportDetails, safePath, sha256 } from './verify-auth-v2.mjs';

const fail = (ok, code) => { if (!ok) throw new Error(code); };
const forbidden = /^(?:src|server|vendor|contracts|tests|\.git)\/|^dist\/browser\/(?:controls\/|sdk\/linked\.js$|wallet\/(?:linkedChainView|renderLinkedChain)\.js$)|^web\/(?:app\.mjs|public-store\.mjs|forward-progress-panel\.mjs)$/;
const linkedSymbols = /\b(?:ResponsibilityWalletSession|ResponsibilityControlClient|NativeResponsibilityPaymentClient|ForwardConsentReview|DetachedResponsibilityHistoryClient|buildLinkedChainView|renderLinkedChain|signForwardConsent|forwardConsentDigest|encodeForward)\b/;

function walk(root, prefix = '') {
  const directory = lstatSync(join(root, prefix));
  fail(directory.isDirectory() && !directory.isSymbolicLink(), 'V2_DIRECTORY_REFUSED');
  return readdirSync(join(root, prefix)).sort().flatMap(name => {
    const path = prefix ? `${prefix}/${name}` : name;
    fail(safePath(path), 'V2_PATH_REFUSED');
    const stat = lstatSync(join(root, path));
    fail(!stat.isSymbolicLink() && (stat.isDirectory() || stat.isFile()) && !(stat.mode & 0o7022), 'V2_UNSAFE_FILE');
    if (stat.isDirectory()) return walk(root, path);
    fail(stat.nlink === 1 && !(stat.mode & 0o111), 'V2_UNSAFE_FILE');
    return [path];
  });
}

function target(root, present, file, specifier) {
  fail(specifier.startsWith('.'), `V2_NONLOCAL_IMPORT: ${file}`);
  const path = relative(root, resolve(root, dirname(file), specifier)).split('\\').join('/');
  fail(present.has(path), `V2_UNRESOLVED_IMPORT: ${file} -> ${specifier}`);
  fail(!forbidden.test(path), `V2_PRIVATE_MODULE_REFUSED: ${path}`);
  return path;
}

export function verifyV2ProductionIsolation(root) {
  const all = walk(root);
  const present = new Set(all);
  for (const file of all) {
    fail(!forbidden.test(file), `V2_PRIVATE_FILE_REFUSED: ${file}`);
    fail(!/\.(?:tar|tgz|zip)(?:\.gz)?$/.test(file), `V2_PRIVATE_FILE_REFUSED: ${file}`);
  }
  const negation = String.raw`(?:not|never|no|without|refuses? to be|yet to be|pending)\s+(?:\w+\s+){0,2}`;
  const claims = ['independently audited', 'security[- ]approved', 'production[- ]ready', 'release[- ]accepted', 'audit(?:ed)? complete'];
  for (const file of all.filter(p => /\.(?:mjs|js|html|css)$/.test(p))) {
    const content = readFileSync(join(root,file),'utf8');
    fail(!claims.some(claim=>new RegExp(String.raw`(?<!${negation})(?:${claim})`,'i').test(content)),'V2_FORBIDDEN_CLAIM: '+file);
  }
  const moduleFiles = all.filter(f => /\.(?:mjs|js)$/.test(f));
  const texts = Object.fromEntries(moduleFiles.map(f => [f, readFileSync(join(root, f), 'utf8')]));
  for (const [file, text] of Object.entries(texts)) fail(!linkedSymbols.test(text), `V2_PRIVATE_IMPLEMENTATION_REFUSED: ${file}`);
  const details = moduleImportDetails(texts);
  const roots = ['web/release-profile.mjs'];
  fail(present.has('web/index.html'),'V2_PAGE_MISSING');
  const page = readFileSync(join(root, 'web/index.html'), 'utf8');
  for(const match of page.matchAll(/<(?:script|link|img|source|video|audio|iframe)\b[^>]*\b(?:src|href)=["']([^"']+)["']/g)){
    fail(!/^(?:[a-z]+:|\/)/i.test(match[1]),'V2_EXTERNAL_ASSET_REFUSED');
    target(root,present,'web/index.html','./'+match[1]);
  }
  fail(/<meta http-equiv="Content-Security-Policy"/.test(page),'V2_PAGE_CSP_MISSING');
  fail(present.has('web/release-config.json')&&present.has('web/release-profile.mjs'),'V2_RELEASE_PROFILE_MISSING');
  for (const match of page.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["']/g)) roots.push(target(root, present, 'web/index.html', './' + match[1]));
  const visited = new Set();
  function visit(file) {
    if (visited.has(file)) return;
    fail(present.has(file), `V2_UNRESOLVED_IMPORT: ${file}`);
    fail(!forbidden.test(file), `V2_PRIVATE_MODULE_REFUSED: ${file}`);
    visited.add(file);
    for (const specifier of [...details[file].static, ...details[file].dynamic]) visit(target(root, present, file, specifier));
  }
  roots.forEach(visit);
  const modules = [...visited].sort();
  fail(JSON.stringify(moduleFiles.slice().sort()) === JSON.stringify(modules), 'V2_UNREACHABLE_MODULE_REFUSED');
  const runtimeFiles = Object.fromEntries(all.filter(f => /^(?:web\/|dist\/browser\/)/.test(f)).map(f => [f, sha256(readFileSync(join(root, f)))]));
  return { schema: '8415wallet-v2-code-isolation/1', moduleFiles: modules, linkedImplementationIncluded: false, runtimeFiles };
}
