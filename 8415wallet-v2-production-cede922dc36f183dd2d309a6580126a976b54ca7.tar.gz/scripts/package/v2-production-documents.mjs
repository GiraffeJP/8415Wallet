/** Authored production product prose and source-closed production document verification.
 * Public-only: no generator import, no canonical PRD text, no private test paths.
 * Shipped in the production kit; the build-time generator imports these constants.
 */
import { createHash } from 'node:crypto';
import { CANONICAL_PRD, REVIEWED_BASELINE, V2_CLAUSES, V2_APPLICABILITY_PATH, V2_CONTRACT_PATH, V2_DOCUMENT_PATHS, V2_DOCUMENT_SCHEMA, confidentialityRefusal, documentDescriptor, linkedRefusal } from './v2-document-contract.mjs';

const fail = (ok, code) => { if (!ok) throw new Error('V2_PRODUCTION_DOCUMENT_' + code); };
const git = /^[a-f0-9]{40}$/;
const hashOf = b => createHash('sha256').update(b).digest('hex');
const stable = o => JSON.stringify(o && typeof o === 'object' ? (Array.isArray(o) ? o.map(x => JSON.parse(stable(x))) : Object.fromEntries(Object.keys(o).sort().map(k => [k, JSON.parse(stable(o[k]))]))) : o);
/** Immutable reviewed applicability projection pin (public baseline value). */
const REVIEWED_PROJECTION = Object.freeze({ bytes: 104922, sha256: '07d1e060b5532c4f9c39655254ce46dbd48a3fe6558fe29a137a747bc5e5ab39' });
export const PRODUCTION_DOCUMENT_SCHEMA = '8415wallet-v2-production-documents/1';

export const PRODUCTION_DELIVERY_DOC = '# 8415wallet V2 production distribution\n\n'
  + '## What this is\n\n'
  + 'This is the finished V2 production distribution of 8415wallet Beta 2.0, a general-purpose multichain wallet with existing wallet and asset standards compatibility and native ERC-8415 support. It contains the runtime-needed V2 browser UI, auth/API runtime, bundled production dependencies, protected install tools, legal notices and authored product documentation. The platform identity is 8415wallet.com; it is not a configured URL or a deployment assertion.\n\n'
  + 'The distribution is generic. The recipient supplies tenant, origin, listener, storage and provider configuration through the protected installers. No tenant instance, service endpoint, credential, private provider implementation or deployment is selected or performed by this artifact.\n\n'
  + '## Validation boundary\n\n'
  + 'This distribution is externally pinned to a successful controlled Linux simulated acceptance receipt. The receipt records synthetic-port source tests and boundary assertions for the retained V2 acceptance contract. It is a source-bound CI record, not cryptographic proof of real network results, and not a security audit, live deployment, real mail delivery, hardware-device success, physical-browser acceptance or on-chain transaction acceptance. The product maturity label remains Beta 2.0.\n\n'
  + '## Fixed document inventory\n\n'
  + '| Path | Role |\n| --- | --- |\n'
  + '| docs/V2-PRD-APPLICABILITY.md | Immutable V2 applicability projection of the canonical requirements |\n'
  + '| docs/V2-DOCUMENT-CONTRACT.json | Clause catalog, source byte spans, dispositions and hash coverage |\n'
  + '| docs/V2-DELIVERY.md | This production delivery boundary |\n'
  + '| docs/V2-PRD-COVERAGE.md | Requirement-family coverage and profile applicability |\n'
  + '| docs/V2-INSTALL.md | Verification, installation preparation and usage |\n\n'
  + '## Contents and exclusions\n\n'
  + 'Included: V2 static browser UI closure, V2 auth/API runtime with bundled production dependencies, protected UI/runtime installers, required legal notices, generated requirement projection, production documentation, hash inventory and the whitelisted public simulation receipt.\n\n'
  + 'Excluded: full development source, Git history, private logs, coordination records, mixed-profile requirements, other-profile runtime, private provider implementations, production configuration, accounts, passwords, keys, certificates, tenant mappings, server identities and native platform applications. Native Android/iOS/Windows/macOS applications remain later platform deliveries.\n';

export const PRODUCTION_INSTALL_DOC = '# 8415wallet V2 install and usage\n\n'
  + '## Scope\n\n'
  + 'This kit contains the V2 browser UI, V2 auth/API runtime and separate protected installers. Verification and extraction never install, activate, provision or deploy anything. The recipient performs any later installation under its own authorization.\n\n'
  + '## Prerequisites\n\n'
  + 'Node 22.18.0 or newer on Linux, GNU tar and gzip. Runtime production dependencies are bundled; no TypeScript compiler, development source checkout or test directory is needed to verify or install. Hardware-CA verification additionally requires the recipient\'s authorized OpenSSL 3 and real device integration; this kit does not provision them. Ordinary asset task/sale integration uses a separately authorized external provider composition; a missing provider is unavailable, never a successful sale.\n\n'
  + '## Verify before writing anything\n\n'
  + '1. Obtain the distribution SHA-256, content-tree pin and simulation-receipt pin from the independent handoff. These out-of-band pins are the trust root; the receipt itself is a source-bound CI record, not proof of real network results.\n'
  + '2. Run `node scripts/package/verify-v2-production.mjs verify <archive> <sha256> <tree> <receipt-sha256>`. Add `--expected-commit <commit>` to also pin the source commit.\n'
  + '3. To materialize a verified payload into a new protected directory, run `node scripts/package/verify-v2-production.mjs extract <archive> <sha256> <tree> <receipt-sha256> <new-directory>`. An existing target is refused.\n\n'
  + 'The verifier enforces the exact production inventory, nested artifact pins, UI runtime closure, auth runtime inventory and import closure, immutable requirement projection, authored production document bytes, public receipt whitelist, source/receipt pins, and refusal of traversal, links, duplicate paths, private material and embedded archives except the two pinned runtime artifacts.\n\n'
  + '## Installation preparation\n\n'
  + 'The UI installer is `deploy/dapp-v2/install.mjs` with `config`, `plan`, `install`, `upgrade` and `rollback` commands; only `--profile v2` is accepted. Supplying `--receipt-sha256 <simulation-receipt-pin>` selects the explicit production mode, which verifies the production schema, documents and public receipt before any protected write; without it the original offline-candidate verification is used unchanged. The auth installer is inside the auth artifact at `deploy/auth-runtime-v2/install.mjs` and requires independent `--expected-tree` and `--expected-manifest-sha256` pins. Both retain explicit tenant, origin, target and pin requirements and never alter services.\n\n'
  + 'The operator supplies the exact existing tenant, expected origin, socket and authoritative encrypted store bindings. Do not create an empty replacement store, overwrite credentials or journals, silently migrate an older mixed-profile runtime, change ports, provision credentials or activate services because verification succeeded. Unknown outcomes must be reconciled, never cleared. Downgrades and incompatible prior profiles fail closed.\n\n'
  + '## Usage after an authorized installation\n\n'
  + 'Serve the complete UI tree with its `web/` and `dist/browser/` layout intact at the exact configured entry path. The public entry stays open; assets, balances, holdings, history and recovery journals require a verified wallet login and are re-locked on reload, logout, expiry and identity changes. Human management and authorization stay in the Web UI; agents use the authenticated API only.\n\n'
  + '## Evidence boundaries\n\n'
  + 'The attached public receipt records controlled Linux simulation validation only. It does not establish a security audit, live deployment, real mail delivery, hardware-token success, physical-browser acceptance or on-chain acceptance. No new authority for transactions, credentials, configuration changes, deployment or notifications is supplied here.\n'
  + "\n## Standalone Pending read source\n\nV2 includes a separate read-only Pending interface in the native read view and in each NFT detail. The NFT identity comes from the selected validated NFT. Enter the exact sequence reference supplied by the configured source; a register ID, watchtower feed or token address is never guessed to be a sequence reference. Missing or unsupported source data stays unavailable.\n\nServer composition may pass `standaloneProgressSource` to the shipped V2 runtime factory. This is a code-owned capability, not an HTTP parameter, module path or credential selected by JSON. Its `8415-v2-standalone-progress-source/1` descriptor has captured source/capability IDs and versions plus `readObservation` and `readMilestone` callbacks. The first supplies an exact principal/asset/sequence/occurrence-bound complete observation and historical observations; the second independently returns the matching canonical immutable observation or explicit unavailable/revoked/reorged status for the requested block, revision and digest. It must read its own trusted source history and lifecycle state; echoing the request, returning a Boolean or assigning a claimed verified label is not source validation. The recipient supplies this existing lawful source composition; the artifact invents no network endpoint, watchtower signing key, financial authority or equivalent ERC-8415 RPC.\n\nThe runtime validates complete coverage, lossless positions, exact bindings, source identity, revision high-water marks, full canonical observations and store CAS before saving. It preserves source-bound forward and coordinated-return milestones across restart, and reports invalidated source evidence as unavailable while retaining the durable record. Return DONE requires the source-bound owner and holder at the user return boundary plus verified NFT return and fund-refund evidence. Funds and return evidence remain distinct; the supplied source remains responsible for its underlying financial provenance. A completed forward observation and a later return observation expose their own block references. Neither read operation authorizes signing, sending, repayment, retry or budget release. These are observations at their actual validation point, not guarantees about unobserved future chain or source state.\n";

export const PRODUCTION_README = '# 8415wallet V2 Beta 2.0\n\n'
  + '8415wallet is a general-purpose multichain wallet with existing wallet and asset standards compatibility and native ERC-8415 support. This is the V2 standalone production distribution. The product maturity label is Beta 2.0.\n\n'
  + '## Capabilities\n\n'
  + '- Verified wallet login and authentication-method management.\n'
  + '- Owner-controlled agent settings with exact-change verification and durable saved state.\n'
  + '- Per-currency total, unreleased escrow and available funds with exact base-unit arithmetic.\n'
  + '- Indicative USD valuation and commodity reference quotations with explicit source/freshness provenance.\n'
  + '- Ordinary NFT browsing and ERC-8415 projection, temporal query, gap and dual-history reads.\n- Source-bound standalone Pending tracks with complete-chain scale, frozen forward milestones and separate coordinated-return evidence.\n'
  + '- Authenticated agent API execution within machine-enforced grants, budgets, nonces and revocation.\n'
  + '- Multichain identity isolation and wrong-chain refusal.\n\n'
  + '## Install\n\n'
  + 'Read `docs/V2-INSTALL.md`. Verify the archive with the independent SHA-256, source-tree and simulation-receipt pins before extraction. The distribution is generic: the recipient supplies tenant, origin, listener, storage and provider configuration. No deployment or service activation is performed by the package.\n\n'
  + '## Validation\n\n'
  + 'This distribution is pinned to a successful controlled Linux simulated acceptance receipt (`SIMULATION-RECEIPT.json`). That receipt is synthetic-port source validation, not a security audit, live deployment, real mail/hardware success or on-chain acceptance.\n\n'
  + '## Documents\n\n'
  + '- `PRODUCT.md`: product boundary and configuration responsibilities.\n'
  + '- `docs/V2-PRD-APPLICABILITY.md`: retained V2 requirement projection.\n'
  + '- `docs/V2-DOCUMENT-CONTRACT.json`: clause traceability.\n'
  + '- `docs/V2-PRD-COVERAGE.md`: requirement-family coverage.\n'
  + '- `SHA256SUMS`: complete payload hash inventory.\n';

export const PRODUCTION_PRODUCT_DOC = '# 8415wallet V2 product boundary\n\n'
  + 'This distribution delivers the V2 standalone capability profile. It does not deliver the linked responsibility profile, native platform applications, a private provider implementation, production credentials or a configured tenant instance.\n\n'
  + '## Recipient configuration\n\n'
  + 'The recipient configures tenant identity, expected origin, listener/socket, encrypted store path, mail transport, CA trust material, read sources and any external provider composition through the protected installers and trusted runtime configuration. The generic template uses the default tenant and an unconfigured endpoint until the recipient supplies those bindings.\n\n'
  + '## Security and reconciliation\n\n'
  + 'Login is not transaction authority. Agent operations remain bound to principal, account, chain, task, assets, fees, expiry and revocation. Owner-saved OFF removes repeated in-scope human verification but does not remove machine-enforced scope, nonce, budget or UNKNOWN reconciliation. Uncertain submitted operations are never blindly resent.\n\n'
  + '## Evidence\n\n'
  + 'The public simulation receipt records controlled Linux synthetic-port validation for the retained acceptance contract. Live deployment, real mail, hardware devices, physical browsers, independent security audit and on-chain acceptance are separate evidence levels and are not asserted by this distribution.\n';

export const PRODUCTION_ROOT_DOCS = Object.freeze({ 'README.md': PRODUCTION_README, 'PRODUCT.md': PRODUCTION_PRODUCT_DOC });

const entryBytes = v => Buffer.isBuffer(v) ? v : Buffer.isBuffer(v?.bytes) ? v.bytes : Buffer.from(v);

/** Source-closed production document verification. No canonical text or generator needed. */
export function verifyProductionDocumentEntries(entries, { source } = {}) {
  fail(entries instanceof Map, 'ENTRIES_REQUIRED');
  fail(source && git.test(source.commit ?? '') && git.test(source.tree ?? '') && source.dirty === false, 'SOURCE_IDENTITY');
  fail([...entries.keys()].sort().join('\n') === [...V2_DOCUMENT_PATHS].sort().join('\n'), 'EXACT_INVENTORY');
  const get = p => entryBytes(entries.get(p));
  let contract;
  try { contract = JSON.parse(get(V2_CONTRACT_PATH).toString('utf8')); } catch { throw new Error('V2_PRODUCTION_DOCUMENT_CONTRACT_PARSE'); }
  fail(contract.schema === V2_DOCUMENT_SCHEMA && contract.profile === 'v2', 'SCHEMA');
  fail(stable(contract.canonical) === stable(CANONICAL_PRD), 'CANONICAL_IDENTITY');
  fail(stable(contract.reviewedBaseline) === stable(REVIEWED_BASELINE), 'REVIEWED_BASELINE');
  fail(contract.projection?.canonicalReplacement === false, 'PROJECTION_KIND');
  fail(stable(contract.source) === stable({ commit: source.commit, tree: source.tree, dirty: source.dirty }), 'SOURCE_IDENTITY');
  fail(stable(contract.production) === stable({ schema: PRODUCTION_DOCUMENT_SCHEMA, replacesOfflineCandidateWording: true }), 'PRODUCTION_MARKER');
  fail(Array.isArray(contract.clauses) && contract.clauses.length === V2_CLAUSES.length, 'CLAUSE_COUNT');
  fail(stable(contract.clauses)===stable(V2_CLAUSES),'CLAUSE_CATALOG');
  fail(stable(contract.coverage)===stable({sourceBytes:CANONICAL_PRD.bytes,classifiedBytes:CANONICAL_PRD.bytes,unclassifiedBytes:0,contiguous:true}),'COVERAGE_BASELINE');
  fail(stable(contract.self)===stable({path:V2_CONTRACT_PATH}),'SELF_BASELINE');
  fail(stable(contract.generator)===stable({module:'scripts/package/v2-document-generator.mjs',version:'1'}),'GENERATOR_BASELINE');
  let at = 0;
  contract.clauses.forEach((c, i) => {
    const expected = V2_CLAUSES[i];
    fail(c.id === expected.id && stable(c.source) === stable(expected.source) && c.source.start === at, 'CLAUSE_SPAN_' + expected.id);
    at = c.source.end;
  });
  fail(at === CANONICAL_PRD.bytes, 'CLAUSE_COVERAGE');
  const expectedDocs = V2_DOCUMENT_PATHS.filter(p => p !== V2_CONTRACT_PATH);
  fail(Array.isArray(contract.documents) && contract.documents.length === expectedDocs.length, 'DOCUMENT_INVENTORY');
  for (const doc of contract.documents) {
    fail(expectedDocs.includes(doc.path), 'DOCUMENT_PATH');
    const b = get(doc.path);
    fail(doc.bytes === b.length && doc.sha256 === hashOf(b), 'DOCUMENT_HASH_' + doc.path);
  }
  for (const p of V2_DOCUMENT_PATHS) fail(!confidentialityRefusal(get(p).toString('utf8')), 'CONFIDENTIALITY_' + p);
  const coverage=get('docs/V2-PRD-COVERAGE.md');
  fail(coverage.length===5065&&hashOf(coverage)==='3390b21dea31f2c14e9874fec4cd3f564a1b3528cb295e9d916b4e015a355e5b','COVERAGE_DOCUMENT');
  const projection = get(V2_APPLICABILITY_PATH);
  fail(projection.length === REVIEWED_PROJECTION.bytes && hashOf(projection) === REVIEWED_PROJECTION.sha256, 'REVIEWED_PROJECTION');
  const text = projection.toString('utf8');
  const marks = [...text.matchAll(/^<!-- v2-clause (c\d+) (included|projected|reference) -->\n/gm)];
  const emitted = V2_CLAUSES.filter(c => c.disposition !== 'excluded');
  fail(marks.length === emitted.length, 'CLAUSE_MARKERS');
  marks.forEach((m, i) => {
    const c = emitted[i], end = i + 1 < marks.length ? marks[i + 1].index : text.length;
    const body = text.slice(m.index + m[0].length, end).replace(/\n+$/, '');
    fail(m[1] === c.id && m[2] === c.disposition, 'CLAUSE_ORDER_' + c.id);
    fail(body.split('\n')[0] === c.heading, 'CLAUSE_HEADING_' + c.id);
    for (const anchor of c.anchors) fail(body.includes(anchor), 'CLAUSE_ANCHOR_' + c.id);
    fail(!linkedRefusal(body), 'LINKED_CONTENT_' + c.id);
  });
  fail(get('docs/V2-DELIVERY.md').equals(Buffer.from(PRODUCTION_DELIVERY_DOC, 'utf8')), 'DOCUMENT_MISMATCH_docs/V2-DELIVERY.md');
  fail(get('docs/V2-INSTALL.md').equals(Buffer.from(PRODUCTION_INSTALL_DOC, 'utf8')), 'DOCUMENT_MISMATCH_docs/V2-INSTALL.md');
  return { descriptor: documentDescriptor(new Map(V2_DOCUMENT_PATHS.map(p => [p, get(p)]))), verified: true };
}
