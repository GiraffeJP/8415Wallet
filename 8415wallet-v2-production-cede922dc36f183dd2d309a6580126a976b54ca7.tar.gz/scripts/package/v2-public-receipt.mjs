/** Public-only simulation receipt contract and strict verifier.
 * Carries ONLY public case IDs, families, kinds, dispositions, counts and the
 * public contract digest. It never carries test paths, commands, the private
 * acceptance CONTRACT, logs or coordination data. Shipped in the production kit.
 */
import { createHash } from 'node:crypto';

export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const hex = /^[a-f0-9]{64}$/;
const git = /^[a-f0-9]{40}$/;
const fail = (ok, code) => { if (!ok) throw new Error('V2_PUBLIC_RECEIPT_' + code); };

export const PUBLIC_RECEIPT_SCHEMA = '8415wallet-v2-public-simulation-receipt/1';
export const ACCEPTED_VERDICT = 'ACCEPTED_SIMULATION';
export const EVIDENCE_LEVEL = 'LINUX_SIMULATED_SYNTHETIC_PORTS';
export const PUBLIC_FAMILY_COUNT = 19;
export const MAX_EVIDENCE_HASHES = 64;

const c = (id, family, kind, disposition) => Object.freeze({ id, family, kind, ...(disposition ? { disposition } : {}) });
const f = (id, kind, disposition) => Object.freeze({ id, kind, ...(disposition ? { disposition } : {}) });

export const PUBLIC_CASES = Object.freeze([
  c('AUTH-01', 'AUTH', 'applicable'), c('AUTH-02', 'AUTH', 'applicable'), c('AUTH-03', 'AUTH', 'applicable'),
  c('ROUTES-01', 'ROUTES', 'applicable'), c('ROUTES-02', 'ROUTES', 'applicable'),
  c('DEFAULT-01', 'INITIAL-ON', 'applicable'), c('DEFAULT-02', 'INITIAL-ON', 'applicable'),
  c('SAVE-01', 'OWNER-SAVE', 'applicable'), c('SAVE-02', 'OWNER-SAVE', 'applicable'), c('SAVE-03', 'OWNER-SAVE', 'applicable'),
  c('FUNDS-01', 'FUNDS', 'applicable'), c('FUNDS-02', 'FUNDS', 'applicable'),
  c('NFT-01', 'NFT', 'applicable'), c('NFT-02', 'NFT', 'applicable'),
  c('MARKET-01', 'MARKET', 'applicable'), c('MARKET-02', 'MARKET', 'applicable'), c('MARKET-03', 'MARKET', 'applicable'),
  c('HUMAN-01', 'HUMAN-OPS', 'applicable'), c('HUMAN-02', 'HUMAN-OPS', 'applicable'), c('HUMAN-03', 'HUMAN-OPS', 'applicable'),
  c('AGENT-01', 'AGENT-OPS', 'applicable'), c('AGENT-02', 'AGENT-OPS', 'applicable'), c('AGENT-03', 'AGENT-OPS', 'applicable'),
  c('MC-01', 'MULTICHAIN', 'applicable'), c('MC-02', 'MULTICHAIN', 'applicable'), c('MC-03', 'MULTICHAIN', 'applicable'),
  c('PROJ-01', 'PROJECTION', 'applicable'), c('PROJ-02', 'PROJECTION', 'applicable'),
  c('HISTORY-01', 'HISTORY', 'applicable'), c('HISTORY-02', 'HISTORY', 'applicable'),
  c('PROGRESS-01', 'PROGRESS', 'applicable'),
  c('PROGRESS-02', 'PROGRESS', 'boundary', 'EXCLUDED_LINKED_BOUNDARY_VERIFIED'),
  c('PROGRESS-03', 'PROGRESS', 'applicable'),
  c('SAFE-01', 'SAFETY', 'applicable'), c('SAFE-02', 'SAFETY', 'applicable'),
  c('PRIVATE-01', 'CONFIDENTIALITY', 'applicable'),
  c('FORUM-01', 'FORUM', 'applicable'),
  c('WEB-01', 'WEB-RELEASE', 'applicable'), c('WEB-02', 'WEB-RELEASE', 'applicable'),
  c('NATIVE-01', 'NATIVE-APPS', 'boundary', 'LATER_PLATFORM_ROADMAP_BOUNDARY_VERIFIED'),
  c('RBAC-01', 'RBAC', 'applicable')
]);

export const PUBLIC_FORUM_CASES = Object.freeze([
  f('FORUM-V2-01', 'applicable'), f('FORUM-V2-02', 'applicable'), f('FORUM-V2-03', 'applicable'),
  f('FORUM-V2-04', 'applicable'), f('FORUM-V2-05', 'applicable'), f('FORUM-V2-06', 'applicable'),
  f('FORUM-V2-07', 'conditional', 'CONDITIONAL_WATCHTOWER_KEY_COMPROMISE_ANNEX_NOT_IMPLEMENTED_BOUNDARY_VERIFIED'),
  f('FORUM-V2-08', 'applicable')
]);

export const PUBLIC_CASE_IDS = Object.freeze(PUBLIC_CASES.map(x => x.id));
export const PUBLIC_FORUM_IDS = Object.freeze(PUBLIC_FORUM_CASES.map(x => x.id));

/** Digest over public-only catalog data; both private and public verifiers pin it. */
export const PUBLIC_CONTRACT = Object.freeze({
  schema: '8415wallet-v2-public-simulation-contract/1',
  evidenceLevel: EVIDENCE_LEVEL,
  familyCount: PUBLIC_FAMILY_COUNT,
  cases: PUBLIC_CASES,
  forumCases: PUBLIC_FORUM_CASES
});
export const PUBLIC_CONTRACT_DIGEST = sha256(Buffer.from(JSON.stringify(PUBLIC_CONTRACT), 'utf8'));

function exactKeys(value, keys, code) {
  fail(value !== null && typeof value === 'object' && !Array.isArray(value), code);
  const own = Reflect.ownKeys(value);
  fail(own.length === keys.length && own.every(k => typeof k === 'string' && keys.includes(k)), code);
}
function sameIds(actual, expected, code) {
  fail(Array.isArray(actual) && actual.length === expected.length, code);
  fail(new Set(actual).size === actual.length, code);
  for (const id of expected) fail(actual.includes(id), code);
}
function hashArray(value, code) {
  fail(Array.isArray(value) && value.length >= 1 && value.length <= MAX_EVIDENCE_HASHES, code);
  fail(new Set(value).size === value.length, code);
  for (const h of value) fail(typeof h === 'string' && hex.test(h), code);
}
function rowStatus(row, catalogRow) {
  return catalogRow.kind === 'applicable' ? 'PASS_SIMULATED' : 'BOUNDARY_VERIFIED';
}

/** Strict whitelisted public receipt verification. External pins are required. */
export function verifyPublicReceipt(value, { expectedCommit, expectedTree, expectedContractDigest = PUBLIC_CONTRACT_DIGEST } = {}) {
  fail(git.test(expectedCommit ?? '') && git.test(expectedTree ?? '') && hex.test(expectedContractDigest ?? ''), 'EXTERNAL_PINS_REQUIRED');
  exactKeys(value, ['schema', 'source', 'contract', 'verdict', 'evidenceLevel', 'cases', 'forumCases'], 'PUBLIC_SHAPE');
  fail(value.schema === PUBLIC_RECEIPT_SCHEMA, 'PUBLIC_SCHEMA');
  exactKeys(value.source, ['commit', 'tree'], 'PUBLIC_SOURCE_SHAPE');
  fail(value.source.commit === expectedCommit && value.source.tree === expectedTree, 'PUBLIC_SOURCE');
  exactKeys(value.contract, ['digest', 'caseCount', 'familyCount', 'forumCaseCount'], 'PUBLIC_CONTRACT_SHAPE');
  fail(value.contract.digest === expectedContractDigest && value.contract.caseCount === 41 && value.contract.familyCount === 19 && value.contract.forumCaseCount === 8, 'PUBLIC_CONTRACT');
  fail(value.verdict === ACCEPTED_VERDICT && value.evidenceLevel === EVIDENCE_LEVEL, 'PUBLIC_VERDICT');
  fail(Array.isArray(value.cases) && Array.isArray(value.forumCases), 'PUBLIC_INVENTORY');
  sameIds(value.cases.map(r => r?.id), PUBLIC_CASE_IDS, 'PUBLIC_CASE_INVENTORY');
  sameIds(value.forumCases.map(r => r?.id), PUBLIC_FORUM_IDS, 'PUBLIC_FORUM_INVENTORY');
  const byId = new Map(PUBLIC_CASES.map(x => [x.id, x]));
  const forumById = new Map(PUBLIC_FORUM_CASES.map(x => [x.id, x]));
  for (const row of value.cases) {
    const expected = byId.get(row.id);
    const keys = expected.kind === 'applicable' ? ['id', 'family', 'status', 'evidenceSha256s'] : ['id', 'family', 'status', 'disposition', 'evidenceSha256s'];
    exactKeys(row, keys, 'PUBLIC_CASE_SHAPE');
    fail(row.family === expected.family, 'PUBLIC_CASE_FAMILY');
    fail(row.status === rowStatus(row, expected), 'PUBLIC_CASE_STATUS');
    if (expected.kind !== 'applicable') fail(row.disposition === expected.disposition, 'PUBLIC_CASE_DISPOSITION');
    hashArray(row.evidenceSha256s, 'PUBLIC_EVIDENCE');
  }
  for (const row of value.forumCases) {
    const expected = forumById.get(row.id);
    const keys = expected.kind === 'applicable' ? ['id', 'status', 'evidenceSha256s'] : ['id', 'status', 'disposition', 'evidenceSha256s'];
    exactKeys(row, keys, 'PUBLIC_FORUM_SHAPE');
    fail(row.status === rowStatus(row, expected), 'PUBLIC_CASE_STATUS');
    if (expected.kind !== 'applicable') fail(row.disposition === expected.disposition, 'PUBLIC_CASE_DISPOSITION');
    hashArray(row.evidenceSha256s, 'PUBLIC_EVIDENCE');
  }
  return true;
}
