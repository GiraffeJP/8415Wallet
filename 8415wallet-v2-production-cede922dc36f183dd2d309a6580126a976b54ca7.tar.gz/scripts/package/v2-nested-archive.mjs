/**
 * Refuse embedded archives anywhere in a public V2 payload, including renamed
 * payloads. Only the two exactly pinned final UI/auth artifacts are exempt, and
 * each of those is separately read, hash-pinned and inventory-verified.
 *
 * Detection is by container magic as well as by suffix, so `notes.json` holding
 * a gzip stream is refused just like `payload.tar.gz`. Licensed runtime
 * dependency files are not archives and are unaffected.
 */
const fail = (ok, code) => { if (!ok) throw Error('V2_NESTED_ARCHIVE_' + code); };

const MAGIC = Object.freeze([
  { name: 'GZIP', offset: 0, bytes: [0x1f, 0x8b] },
  { name: 'ZIP', offset: 0, bytes: [0x50, 0x4b, 0x03, 0x04] },
  { name: 'ZIP_EMPTY', offset: 0, bytes: [0x50, 0x4b, 0x05, 0x06] },
  { name: 'ZIP_SPANNED', offset: 0, bytes: [0x50, 0x4b, 0x07, 0x08] },
  { name: 'BZIP2', offset: 0, bytes: [0x42, 0x5a, 0x68] },
  { name: 'XZ', offset: 0, bytes: [0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00] },
  { name: 'SEVENZ', offset: 0, bytes: [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c] },
  { name: 'ZSTD', offset: 0, bytes: [0x28, 0xb5, 0x2f, 0xfd] },
  { name: 'LZIP', offset: 0, bytes: [0x4c, 0x5a, 0x49, 0x50] },
  { name: 'TAR', offset: 257, bytes: [0x75, 0x73, 0x74, 0x61, 0x72] },
]);

export const ARCHIVE_SUFFIX = /\.(?:tar|tgz|tbz|tbz2|gz|bz2|xz|zst|lz|zip|7z|jar|war)$/i;

export function archivePathRefusal(path) {
  return typeof path === 'string' && ARCHIVE_SUFFIX.test(path) ? 'PATH' : null;
}

export function archiveMagicRefusal(bytes) {
  const buffer = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes);
  for (const magic of MAGIC) {
    if (buffer.length < magic.offset + magic.bytes.length) continue;
    let hit = true;
    for (let i = 0; i < magic.bytes.length; i += 1) {
      if (buffer[magic.offset + i] !== magic.bytes[i]) { hit = false; break; }
    }
    if (hit) return magic.name;
  }
  return null;
}

/** `entries` may hold buffers or `{bytes,mode}` archive records. */
export function verifyNoEmbeddedArchives(entries, { allowed = [] } = {}) {
  fail(entries instanceof Map, 'ENTRIES_REQUIRED');
  const exempt = new Set(allowed);
  for (const [path, entry] of entries) {
    if (exempt.has(path)) continue;
    fail(!archivePathRefusal(path), 'PATH_REFUSED:' + path);
    const bytes = Buffer.isBuffer(entry) ? entry
      : Buffer.isBuffer(entry?.bytes) ? entry.bytes : Buffer.from(entry);
    const magic = archiveMagicRefusal(bytes);
    fail(!magic, 'MAGIC_REFUSED:' + path + ':' + magic);
  }
  return true;
}
