/** Independent strict verifier for the finished V2 production distribution.
 * Source-closed: imports only modules shipped in the production kit. No private
 * acceptance contract, no generator, no TypeScript compiler, no full-source tools.
 * Never installs or activates a service.
 */
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { readDeliveryArchive } from './archive-v2.mjs';
import { sha256, safePath, verifyAuthDirectory } from './verify-auth-v2.mjs';
import { DELIVERY_TOOL_FILES, DELIVERY_FILES, extractDelivery } from './verify-v2-delivery.mjs';
import { CANONICAL_PRD, V2_APPLICABILITY_PATH, V2_DOCUMENT_PATHS, V2_UI_LEGAL_FILES, documentDescriptor } from './v2-document-contract.mjs';
import { verifyNoEmbeddedArchives } from './v2-nested-archive.mjs';
import { verifyV2ProductionIsolation } from './v2-production-isolation.mjs';
import { resolveReleaseProfile } from '../../web/release-profile-v2.mjs';
import { verifyPublicReceipt, PUBLIC_CONTRACT_DIGEST, ACCEPTED_VERDICT } from './v2-public-receipt.mjs';
import { PRODUCTION_ROOT_DOCS, verifyProductionDocumentEntries } from './v2-production-documents.mjs';
import { isPublicFile } from './verify-v2-delivery.mjs';

export const PRODUCTION_DELIVERY_SCHEMA = '8415wallet-public-v2-production/1';
export const PRODUCTION_STATUS = 'PRODUCTION_DISTRIBUTION_SIMULATION_VALIDATED';
export const PRODUCTION_EXTRA_TOOL_FILES = Object.freeze([]);
export const PRODUCTION_TOOL_FILES = Object.freeze([...DELIVERY_TOOL_FILES, ...PRODUCTION_EXTRA_TOOL_FILES]);
export const PRODUCTION_EXTRA_FILES = Object.freeze(['PRODUCTION.json', 'SIMULATION-RECEIPT.json', ...Object.keys(PRODUCTION_ROOT_DOCS)]);
const check = (ok, code) => { if (!ok) throw new Error('V2_PRODUCTION_' + code); };
const hash = /^[a-f0-9]{64}$/, tree = /^[a-f0-9]{40}$/;
const get = (entries, path) => { check(entries.has(path), 'MISSING_' + path); return entries.get(path).bytes; };
const parsed = (entries, path) => JSON.parse(get(entries, path).toString('utf8'));
const sums = entries => [...entries].filter(([p]) => p !== 'SHA256SUMS').sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([p, e]) => `${sha256(e.bytes)}  ${p}`).join('\n') + '\n';

function writeTree(entries, root) {
  for (const [p, e] of entries) { mkdirSync(dirname(join(root, p)), { recursive: true, mode: 0o755 }); writeFileSync(join(root, p), e.bytes, { flag: 'wx', mode: 0o644 }); }
}

export function verifyV2ProductionArchive(archive, { expectedSha256, expectedTree, expectedCommit, expectedReceiptSha256 } = {}) {
  check(hash.test(expectedSha256 ?? '') && tree.test(expectedTree ?? '') && hash.test(expectedReceiptSha256 ?? ''), 'EXTERNAL_PINS_REQUIRED');
  check(expectedCommit === undefined || tree.test(expectedCommit), 'COMMIT_PIN_REFUSED');
  const entries = readDeliveryArchive(archive, expectedSha256);
  const release = parsed(entries, 'DELIVERY.json');
  check(release.schema === PRODUCTION_DELIVERY_SCHEMA && release.profile === 'v2' && release.status === PRODUCTION_STATUS, 'PROFILE_STATUS');
  check(release.source && release.source.tree === expectedTree && (expectedCommit === undefined || release.source.commit === expectedCommit), 'SOURCE_IDENTITY');
  assert.deepEqual(Object.keys(release.source).sort(), ['commit', 'dirty', 'tree']);
  check(release.source.dirty === false, 'DIRTY_SOURCE');
  check(release.production && release.production.receiptSha256 === expectedReceiptSha256 && release.production.contractDigest === PUBLIC_CONTRACT_DIGEST && release.production.verdict === ACCEPTED_VERDICT, 'PRODUCTION_RECEIPT_PIN');
  const receiptBytes = get(entries, 'SIMULATION-RECEIPT.json');
  check(sha256(receiptBytes) === expectedReceiptSha256, 'RECEIPT_HASH');
  const receipt = JSON.parse(receiptBytes.toString('utf8'));
  verifyPublicReceipt(receipt, { expectedCommit: release.source.commit, expectedTree: release.source.tree, expectedContractDigest: PUBLIC_CONTRACT_DIGEST });
  const production = parsed(entries, 'PRODUCTION.json');
  assert.deepEqual(production, { schema: PRODUCTION_DELIVERY_SCHEMA, status: PRODUCTION_STATUS, source: release.source, receiptSha256: expectedReceiptSha256, contractDigest: PUBLIC_CONTRACT_DIGEST, verdict: ACCEPTED_VERDICT, maturityLabel: 'Beta 2.0' }, 'PRODUCTION_METADATA');
  for (const [path, text] of Object.entries(PRODUCTION_ROOT_DOCS)) check(get(entries, path).toString('utf8') === text, 'ROOT_DOC_' + path);
  check(get(entries, 'SHA256SUMS').toString() === sums(entries), 'SUMS_MISMATCH');
  const expected = new Set([...DELIVERY_FILES, ...PRODUCTION_EXTRA_TOOL_FILES, ...PRODUCTION_EXTRA_FILES, 'DELIVERY.json', 'SHA256SUMS']);
  const nested = [];
  assert.deepEqual(Object.keys(release.artifacts).sort(), ['auth', 'v2']);
  for (const item of Object.values(release.artifacts)) { check(item && safePath(item.artifact) && !item.artifact.includes('/') && hash.test(item.sha256), 'ARTIFACT_REFUSED'); expected.add('artifacts/' + item.artifact); nested.push('artifacts/' + item.artifact); check(sha256(get(entries, 'artifacts/' + item.artifact)) === item.sha256, 'ARTIFACT_HASH'); }
  assert.deepEqual([...entries.keys()].sort(), [...expected].sort(), 'EXACT_INVENTORY');
  const fileHashes = Object.fromEntries([...DELIVERY_FILES, ...PRODUCTION_EXTRA_TOOL_FILES, ...PRODUCTION_EXTRA_FILES].map(p => [p, sha256(get(entries, p))]));
  assert.deepEqual(release.files, fileHashes, 'FILE_HASHES');
  verifyNoEmbeddedArchives(entries, { allowed: nested });
  for (const [p] of entries) check(!/(?:^|\/)(?:\.git|AGENTS\.md|.*\.private\.|credentials|store-key)(?:$|\/|\.)/.test(p), 'PRIVATE_PAYLOAD_' + p);
  for (const [p] of entries) check(!p.startsWith('tests/') && !p.startsWith('scripts/acceptance/'), 'PRIVATE_TEST_CATALOG_' + p);

  const ui = readDeliveryArchive(get(entries, 'artifacts/' + release.artifacts.v2.artifact), release.artifacts.v2.sha256);
  const uiRelease = parsed(ui, 'RELEASE.json');
  check(uiRelease.schema === '8415wallet-public-v2/1' && uiRelease.profile === 'v2' && uiRelease.status === PRODUCTION_STATUS && uiRelease.source.tree === expectedTree, 'UI_IDENTITY');
  assert.deepEqual(uiRelease.source, release.source, 'UI_SOURCE');
  check(!Object.hasOwn(uiRelease, 'sourceArchive'), 'FULL_SOURCE_REFUSED');
  check(uiRelease.distribution?.authRuntimeIncluded === false && uiRelease.distribution?.v3Included === false, 'UI_DISTRIBUTION_SCOPE');
  const uiRoot = mkdtempSync(join(tmpdir(), 'v2-production-ui-'));
  const authRoot = mkdtempSync(join(tmpdir(), 'v2-production-auth-'));
  try {
    writeTree(ui, uiRoot);
    const profile = resolveReleaseProfile(parsed(ui, 'web/release-config.json'));
    check(profile.id === 'v2' && !profile.features.linkedResponsibilities, 'UI_PROFILE');
    assert.deepEqual(profile.features, uiRelease.features, 'UI_FEATURES');
    check(uiRelease.build?.configSha256 === sha256(get(ui, 'web/release-config.json')), 'UI_CONFIG_MISMATCH');
    const isolation = verifyV2ProductionIsolation(uiRoot);
    assert.deepEqual(uiRelease.codeIsolation, isolation, 'UI_CLOSURE');
    const documents = verifyProductionDocumentEntries(new Map(V2_DOCUMENT_PATHS.map(p => [p, ui.get(p)])), { source: release.source });
    assert.deepEqual(uiRelease.documents, documents.descriptor, 'UI_DOCUMENT_DESCRIPTOR');
    check(uiRelease.prd.file === V2_APPLICABILITY_PATH && uiRelease.prd.canonicalSha256 === CANONICAL_PRD.sha256, 'UI_PRD_PROVENANCE');
    check(uiRelease.prd.sha256 === sha256(get(ui, V2_APPLICABILITY_PATH)) && uiRelease.prd.sha256 !== CANONICAL_PRD.sha256, 'UI_PRD_PROJECTION');
    check(get(ui, 'SHA256SUMS').toString() === sums(ui), 'UI_SUMS');
    const uiAllowed = new Set(['RELEASE.json', 'SHA256SUMS', ...V2_UI_LEGAL_FILES, ...V2_DOCUMENT_PATHS, ...Object.keys(uiRelease.codeIsolation.runtimeFiles)]);
    assert.deepEqual([...ui.keys()].sort(), [...uiAllowed].sort(), 'UI_EXACT_INVENTORY');
    const runtime = new Map([...ui].filter(([p]) => p.startsWith('web/') || p.startsWith('dist/browser/')));
    check([...runtime.keys()].every(isPublicFile) && runtime.has('web/index.html'), 'UI_RUNTIME_REFUSED');
    verifyNoEmbeddedArchives(ui);
    for (const path of V2_DOCUMENT_PATHS) check(get(ui, path).equals(get(entries, path)), 'DOCUMENT_SET_MISMATCH');

    const authEntries = readDeliveryArchive(get(entries, 'artifacts/' + release.artifacts.auth.artifact), release.artifacts.auth.sha256);
    verifyNoEmbeddedArchives(authEntries);
    writeTree(authEntries, authRoot);
    const auth = verifyAuthDirectory(authRoot, { expectedTree, expectedCommit: release.source.commit });
    assert.deepEqual({ commit: auth.source.commit, tree: auth.source.tree, dirty: auth.source.dirty }, release.source, 'AUTH_SOURCE');
    check(auth.source.prdSha256 === CANONICAL_PRD.sha256, 'AUTH_CANONICAL_PROVENANCE');
    check(auth.runtime.credentialStoreFormat === 5 && auth.runtime.authStateSemantics === '8415wallet-auth-state/8', 'AUTH_STATE_FORMAT');
    return { release, entries, dapps: { v2: { release: uiRelease, runtime } }, authRuntime: authEntries, sha256: expectedSha256, receiptSha256: expectedReceiptSha256, documents: documents.descriptor, auth, ui: uiRelease, verified: true, installed: false };
  } finally { rmSync(uiRoot, { recursive: true, force: true }); rmSync(authRoot, { recursive: true, force: true }); }
}

export function extractProduction(result, destination) {
  return extractDelivery(result, destination);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  let expectedCommit;
  const ci = args.indexOf('--expected-commit');
  if (ci >= 0) { expectedCommit = args[ci + 1]; args.splice(ci, 2); }
  const [command, archive, expectedSha256, expectedTree, expectedReceiptSha256, destination, ...extra] = args;
  check(['verify', 'extract'].includes(command) && archive && expectedSha256 && expectedTree && expectedReceiptSha256 && extra.length === 0 && (command === 'extract' ? destination !== undefined : destination === undefined), 'ARGUMENT_REFUSED');
  const result = verifyV2ProductionArchive(resolve(archive), { expectedSha256, expectedTree, expectedCommit, expectedReceiptSha256 });
  if (command === 'extract') extractProduction(result, resolve(destination));
  console.log(JSON.stringify({ profile: 'v2', status: PRODUCTION_STATUS, sourceTree: expectedTree, sha256: expectedSha256, receiptSha256: expectedReceiptSha256, verified: true, extracted: command === 'extract', installed: false }));
}
