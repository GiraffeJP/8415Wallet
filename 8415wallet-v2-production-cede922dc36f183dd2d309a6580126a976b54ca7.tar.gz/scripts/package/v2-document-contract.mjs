/** V2-only delivery verification against an immutable reviewed document baseline. */
import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
const fail=(ok,code)=>{if(!ok)throw Error('V2_DOCUMENT_'+code);};
const git=/^[a-f0-9]{40}$/;
const freeze=o=>{if(o&&typeof o==='object'){Object.values(o).forEach(freeze);Object.freeze(o);}return o;};
const stable=o=>JSON.stringify(o&&typeof o==='object'?(Array.isArray(o)?o.map(x=>JSON.parse(stable(x))):Object.fromEntries(Object.keys(o).sort().map(k=>[k,JSON.parse(stable(o[k]))]))):o);

const BASELINE=freeze({
  "schema": "8415wallet-v2-document-contract/1",
  "profile": "v2",
  "generator": {
    "module": "scripts/package/v2-document-generator.mjs",
    "version": "1"
  },
  "canonical": {
    "path": "docs/ERC-8415-Wallet-PRD.md",
    "sha256": "c256e57dd1ee54ecab22db82b092bea4b5b3feca78076bc9ccacddd4ea3427b3",
    "bytes": 126930,
    "gitBlobSHA1": "9bbe6ea90b7fd8157a73e5932f6bba7d57ba9d06",
    "revision": "2026-11-12-password-rule-8-two-classes",
    "releaseLabel": "Beta 2.0"
  },
  "reviewedBaseline": {
    "commit": "68511f527da894f0544adcdafaa3e8daf9c0b2f7",
    "tree": "f8a075ebbba7b4322c897b764d62812d52d261f4"
  },
  "projection": {
    "kind": "v2-applicability-projection",
    "canonicalReplacement": false,
    "clauseCount": 18,
    "emittedClauseCount": 16
  },
  "clauses": [
    {
      "id": "c0",
      "heading": "# 8415wallet Beta 2.0 Product Requirements",
      "disposition": "projected",
      "reason": "Shared release, default-value, interface, platform and market-data decisions apply to V2. Other-profile release/version framing is projected; the linked responsibility clarification states no V2 requirement and is excluded paragraph-wise.",
      "anchors": [
        "ALL Agent-operation, asset-scope and authorization ON/OFF controls have the initial default ON",
        "§§6.5.1 and 10.7.1 define separately bound historical observation provenance",
        "indicative USD holdings valuation and commodity reference quotes are required under §10.4.1"
      ],
      "source": {
        "start": 0,
        "end": 2795,
        "bytes": 2795,
        "sha256": "c6aecc3e6e88af3835e22c30f558c31b03f27fb7552fd19e1be0819d9553d40d"
      },
      "output": {
        "bytes": 2330,
        "sha256": "b86e081ec2746ddf2b0d5fe480b4c5ea7e95922f8619e97628cfc14e8b05f1be"
      },
      "applied": {
        "projections": [
          "p-c0-release",
          "p-c0-version"
        ],
        "exclusions": [
          "x-c0-responsibility"
        ],
        "substitutions": []
      }
    },
    {
      "id": "c1",
      "heading": "Excluded source clause c1",
      "disposition": "excluded",
      "reason": "Superseded revision narrative (history). Every requirement it describes is carried by the current section 2 text, which is included in full; no requirement is dropped.",
      "anchors": [],
      "source": {
        "start": 2795,
        "end": 3344,
        "bytes": 549,
        "sha256": "571fc537b42cd10a7189304647936dd3cdf2765d053d38fa8a7dc53df8e7653a"
      },
      "output": null,
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c2",
      "heading": "## Product Definition",
      "disposition": "projected",
      "reason": "Core product identity, multichain and agentic principles, login/authentication, password rule 8 and references apply to V2. Other-profile deliverable framing is projected; references to non-delivered documents are redirected to the delivered coverage record.",
      "anchors": [
        "at least 8 JavaScript",
        "at most 1024 UTF-8 bytes",
        "at least two of four",
        "Multichain compatibility is part of the product",
        "Login supports password, standard authenticator-generated TOTP",
        "Reset-only reserved-email OTP"
      ],
      "source": {
        "start": 3344,
        "end": 10832,
        "bytes": 7488,
        "sha256": "d482506029a2c0c5854aeeab386008510723be24be52aa2b628234f62a145300"
      },
      "output": {
        "bytes": 7508,
        "sha256": "7971144e7830a48ca010a8a2a7bd84b46f37d3eafb5643e71121ba62e79ae37f"
      },
      "applied": {
        "projections": [
          "p-c2-general",
          "p-c2-deliverable",
          "p-c2-surface"
        ],
        "exclusions": [],
        "substitutions": [
          "s-security-matrix",
          "s-auth-recovery",
          "s-email-registration",
          "s-wallet-login",
          "s-account-auth",
          "s-standards"
        ]
      }
    },
    {
      "id": "c3",
      "heading": "## Multichain compatibility and acceptance",
      "disposition": "projected",
      "reason": "MC-01 to MC-08 are V2 requirements. Only the MC-06 reference to the other profile responsibility semantics is projected.",
      "anchors": [
        "MC-01",
        "MC-08",
        "Ethereum (chain ID 1) is the default network"
      ],
      "source": {
        "start": 10832,
        "end": 16472,
        "bytes": 5640,
        "sha256": "b1f77d568f0b7e91d159802770d354000f8723be5230fa595202be1287129111"
      },
      "output": {
        "bytes": 5635,
        "sha256": "53ed1f4d89ec37efc5229c55424722dc7f80f857ac98b50a6d02f39af07902a7"
      },
      "applied": {
        "projections": [
          "p-c3-mc06"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c4",
      "heading": "# 1. Design Principle",
      "disposition": "included",
      "reason": "Shared standalone design principle; reproduced verbatim.",
      "anchors": [
        "Who holds the tradeable position now?",
        "holderAsOf(tokenId, t)"
      ],
      "source": {
        "start": 16472,
        "end": 17467,
        "bytes": 995,
        "sha256": "51f00c2514fa83c97ea71f12acbeb5e73cfb86dbc1ac89b0dae08ae3f08433f5"
      },
      "output": {
        "bytes": 993,
        "sha256": "eb81f10055e15e01289ba8b8cbe175078677a37b41d4cc0e94068b26a3553c77"
      },
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c5",
      "heading": "# 2. Core Architecture",
      "disposition": "included",
      "reason": "Shared architecture, adapters, backend cross-checks and selector agreement; reproduced verbatim.",
      "anchors": [
        "Two adapters, one port",
        "The wallet MUST NOT redefine ERC-8415 semantics."
      ],
      "source": {
        "start": 17467,
        "end": 21889,
        "bytes": 4422,
        "sha256": "7856ca3ab8a566fb7613ddaac2f0959b1a3176fe4e4e2e3525db7db76f501ad7"
      },
      "output": {
        "bytes": 4420,
        "sha256": "bd5ee7ecf5560f48701708b8cc6914a21569349fe1456f94b5200c71eae5f653"
      },
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c6",
      "heading": "# 3. Data Model",
      "disposition": "projected",
      "reason": "Shared protocol data model. Only the sentence pointing at the other-profile obligation model is projected.",
      "anchors": [
        "recordCommitment",
        "settlementId",
        "0x6309e170"
      ],
      "source": {
        "start": 21889,
        "end": 23980,
        "bytes": 2091,
        "sha256": "c52ed7f56adf47d145715a50cf28d285b0fc89a4bf82628f96b973572b47c984"
      },
      "output": {
        "bytes": 2044,
        "sha256": "135165f75cd511abd548adec7e1c6e8dfad8db71d8c233d9dd3b95308bbb11d8"
      },
      "applied": {
        "projections": [
          "p-c3-model"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c7",
      "heading": "# 4. Core Features",
      "disposition": "projected",
      "reason": "Asset view, temporal query, finality, history, gaps, risk surfaces, holder questions, acquisition disclosure, collisions and snapshots are V2 requirements. Only other-profile closing sentences are projected.",
      "anchors": [
        "Tradeable position",
        "Finality Display",
        "Projection History",
        "Gap Awareness",
        "Reads are snapshots"
      ],
      "source": {
        "start": 23980,
        "end": 35934,
        "bytes": 11954,
        "sha256": "c7236b9e22b86c056b6363f565ae55e78cd240a4c73f7dd1a1b113c31c1ceca0"
      },
      "output": {
        "bytes": 11709,
        "sha256": "b34a72e0dedc84e07354b54666fa40090527760497ab344dfbc14a302728e9de"
      },
      "applied": {
        "projections": [
          "p-c7-risk",
          "p-c7-gap",
          "p-c7-acquire"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c8",
      "heading": "# 5. Application Patterns",
      "disposition": "projected",
      "reason": "Trading, custody and record-instant patterns apply to V2 including the retained legacy single-trade clearing path. Only the other-profile execution reference is projected.",
      "anchors": [
        "Trading",
        "Custody",
        "Rights and record instants"
      ],
      "source": {
        "start": 35934,
        "end": 38385,
        "bytes": 2451,
        "sha256": "860b018fd24aeb4bb5281a0d20103277cb8ca5e19f0b570980cddd14ee77f86b"
      },
      "output": {
        "bytes": 2453,
        "sha256": "284efbaed7f3af541bdcaf6a229380882ffb4a7d718e235e1c90fc222fdba060"
      },
      "applied": {
        "projections": [
          "p-c8-trading"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c9",
      "heading": "# 6. Security Requirements",
      "disposition": "projected",
      "reason": "Sections 6.1 to 6.5.1 apply to V2: asset/protocol boundaries, task authority, TOTP task authorization, the owner verification switch, method changes, budgets/recovery/audit and historical observation provenance. Profile framing and one cross-reference are projected.",
      "anchors": [
        "Task authority and agent execution",
        "Owner-controlled per-operation verification switch",
        "Historical observation identity and read-only compatibility",
        "Default value: ON."
      ],
      "source": {
        "start": 38385,
        "end": 58478,
        "bytes": 20093,
        "sha256": "b987da3a101822b82ed26d168fbf0d25d18641fe70a5bca699fc83306c209bdd"
      },
      "output": {
        "bytes": 20004,
        "sha256": "7262c7a55604844937b9805f02433dc11acd0e391374b6fd39477c1d73697332"
      },
      "applied": {
        "projections": [
          "p-c9-intro",
          "p-c9-observation"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c10",
      "heading": "## 6.6 Implementation and acceptance evidence",
      "disposition": "projected",
      "reason": "Historical implementation/evidence narrative with a superseded candidate identity. Projected to the V2 evidence-level requirements it establishes; no requirement is dropped and no historical evidence value is republished.",
      "anchors": [
        "NOT_RUN"
      ],
      "source": {
        "start": 58478,
        "end": 60067,
        "bytes": 1589,
        "sha256": "ddbfca648e5108c07c1edaffd314cc163bc7ea3b9117cbb8f27733e0620617c1"
      },
      "output": {
        "bytes": 1020,
        "sha256": "b3c3b242fab11f7e24d704c35d0b6b0667c6ce0c882580fd47a847c9fccd5ddc"
      },
      "applied": {
        "projections": [
          "p-c10-evidence"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c11",
      "heading": "# 7. Development Stages",
      "disposition": "included",
      "reason": "Stages 0 to 5 are the retained V2 foundation stages; reproduced verbatim.",
      "anchors": [
        "Stage 0 — Project foundation",
        "Stage 5 — Freshness annex"
      ],
      "source": {
        "start": 60067,
        "end": 61058,
        "bytes": 991,
        "sha256": "2787a83bfeaa11fe5b3a1ae3ff4dfdc643d41750815dc1f806485587aeb2bb1c"
      },
      "output": {
        "bytes": 989,
        "sha256": "cfb669deff67946bea7e075c4399f0c97fdd655d4577b9407410f761096b6d3c"
      },
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c12",
      "heading": "# 8. Standalone foundation — definition of done",
      "disposition": "projected",
      "reason": "The seven definition-of-done conditions are V2 requirements and are retained verbatim. The closing historical record with deployment values and non-delivered document paths is projected to the same evidence boundary.",
      "anchors": [
        "see the tradeable position and the confirmed holder as two separate facts"
      ],
      "source": {
        "start": 61058,
        "end": 62652,
        "bytes": 1594,
        "sha256": "f688b62806d838ac9e3eacf4084e3dec4e34eca23dd3922a181559c6b434affc"
      },
      "output": {
        "bytes": 1505,
        "sha256": "94113672fc234fdec2da9f69b523f139e77c622da0acc04222420d47f66a54c8"
      },
      "applied": {
        "projections": [
          "p-c12-closeout"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c13",
      "heading": "Excluded source clause c13",
      "disposition": "excluded",
      "reason": "Out-of-profile canonical clause. Its source range is retained only as traceability metadata; it adds no V2 requirement.",
      "anchors": [],
      "source": {
        "start": 62652,
        "end": 84411,
        "bytes": 21759,
        "sha256": "09238f12b3a888a903f388b56ffa076a01a2e3c237e8800e33dbc0cceda33f2e"
      },
      "output": null,
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c14",
      "heading": "# 10. Beta 2.0 complete UI and API requirements",
      "disposition": "projected",
      "reason": "Sections 10.1 to 10.8 are shared V2 UI/API requirements: entry, initialization, agent controls, funds and valuation, NFT browsing, Pending/rollback privacy, transfers, observation details, confidentiality and acceptance. Other-profile acceptance obligations are projected or excluded; the owner V2-only release scope supersedes the earlier cross-profile wait.",
      "anchors": [
        "Tenant name, email or wallet address",
        "noreply@8415wallet.com",
        "Allow Agent — ON/OFF",
        "unreleased escrow",
        "Per-operation human verification",
        "Refresh observation",
        "Institutional wallet access (RBAC)"
      ],
      "source": {
        "start": 84411,
        "end": 116004,
        "bytes": 31593,
        "sha256": "46bd8516aa36abba5a015e7f5f3a872c7ada55fb4ed6f4a61978f0ac97a9855e"
      },
      "output": {
        "bytes": 31278,
        "sha256": "296618097f14885792af52a59b14b6b00c17589e563881daa9e12b289aac1f7a"
      },
      "applied": {
        "projections": [
          "p-c14-entry",
          "p-c14-forward",
          "p-c14-rollback",
          "p-c14-about",
          "p-c14-observation-ui",
          "p-c14-release-sequence",
          "p-c14-applicability",
          "p-c14-forum",
          "p-c14-records"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c15",
      "heading": "## 10.9 Staged Web and platform application delivery",
      "disposition": "projected",
      "reason": "Staged Web-first then Android/iOS/Windows/macOS platform requirements apply to V2. Only the shared-profile wording is projected to the V2 capability set.",
      "anchors": [
        "Android",
        "iOS",
        "Windows",
        "macOS",
        "protected storage"
      ],
      "source": {
        "start": 116004,
        "end": 120523,
        "bytes": 4519,
        "sha256": "9b9a994f1d4d1397dfd37ef4fe8854e1c86fbd43b5804e76f95fe224fb4a719c"
      },
      "output": {
        "bytes": 4536,
        "sha256": "e5a584d907b5ecd4d7aeacf8c96434e7821dbc5fdf7f88f6917d1715f1176e3b"
      },
      "applied": {
        "projections": [
          "p-c15-web",
          "p-c15-minimum",
          "p-c15-table"
        ],
        "exclusions": [],
        "substitutions": []
      }
    },
    {
      "id": "c16",
      "heading": "# Appendix A — changes from v1.0",
      "disposition": "reference",
      "reason": "Classified reference history: the v1.0 corrections explain the retained semantics in sections 3, 4 and 6. Retained with the reviewed substitution of the internal development-instruction file name.",
      "anchors": [
        "Instants.",
        "Finality."
      ],
      "source": {
        "start": 120523,
        "end": 123454,
        "bytes": 2931,
        "sha256": "ece795413ab0254f2d0f6cd14e90c0f4653568d696441dc993de93a2129dc4ac"
      },
      "output": {
        "bytes": 2987,
        "sha256": "3bd2f41098dd9dba4e2887878132257fb4cc451128b34b5d7cfa4074ef8ce3ea"
      },
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": [
          "s-development-file"
        ]
      }
    },
    {
      "id": "c17",
      "heading": "# Appendix B — what v2.1 adds, and why",
      "disposition": "reference",
      "reason": "Classified reference history: the public discussion rationale for sections 4.7 to 4.10 and 5, including the requirement that reported agreement is never presented as verified legal identity. Retained with the reviewed substitution of the internal development-instruction file name.",
      "anchors": [
        "Serial registration and the hops behind (§4.7).",
        "Acquisition-time disclosure (§4.8)."
      ],
      "source": {
        "start": 123454,
        "end": 126930,
        "bytes": 3476,
        "sha256": "80ff3ed1619032300b44830b87359430b1f3f14195c96cbed2d1f0c8d478b6f9"
      },
      "output": {
        "bytes": 3503,
        "sha256": "a3de6a7996010893fd3c35573ffa0438ef000dd24e34f7ea442ebb70b464da25"
      },
      "applied": {
        "projections": [],
        "exclusions": [],
        "substitutions": [
          "s-development-file"
        ]
      }
    }
  ],
  "coverage": {
    "sourceBytes": 126930,
    "classifiedBytes": 126930,
    "unclassifiedBytes": 0,
    "contiguous": true
  },
  "documents": [
    {
      "path": "docs/V2-PRD-APPLICABILITY.md",
      "bytes": 104922,
      "sha256": "07d1e060b5532c4f9c39655254ce46dbd48a3fe6558fe29a137a747bc5e5ab39"
    },
    {
      "path": "docs/V2-DELIVERY.md",
      "bytes": 2931,
      "sha256": "47104cef823267336044d7c0f8c7fd4ce3e1202f9d6a3252d87ace85109cc9e8"
    },
    {
      "path": "docs/V2-PRD-COVERAGE.md",
      "bytes": 5065,
      "sha256": "3390b21dea31f2c14e9874fec4cd3f564a1b3528cb295e9d916b4e015a355e5b"
    },
    {
      "path": "docs/V2-INSTALL.md",
      "bytes": 6509,
      "sha256": "6bcba442929f108639b56f28c97a996be1f8adf3fd5c04a14b7df080ea2ccc71"
    }
  ],
  "self": {
    "path": "docs/V2-DOCUMENT-CONTRACT.json"
  }
});

/** Other-profile requirement prose that must never appear in a delivered clause. */
const LINKED_PATTERNS = Object.freeze([
  /\bV3\b/, /\bv3\.0\b/, /\bW-\d{2}\b/, /\bCP-01\b/,
  /linked\s+(?:mode|responsibilit\w*|receipt|forwarding|chain|use)/i,
  /§\s*9\b/, /§§\s*9/, /responsibility\s+control/i,
  /\bdetach(?:ed|es|ing|ment)?\b/i, /forward\s+consent/i,
]);
export function linkedRefusal(text) {
  for (const pattern of LINKED_PATTERNS) if (pattern.test(text)) return String(pattern);
  return null;
}

/**
 * Confidentiality policy. Public product/standards hosts, the documented product
 * sender, loopback, reserved documentation networks and declared synthetic
 * fixture addresses are allowed; real operational identities are not.
 */
const PUBLIC_HOSTS = new Set(['8415wallet.com', 'www.8415wallet.com', 'ethereum.org', 'eips.ethereum.org', 'ercs.ethereum.org', 'www.rfc-editor.org', 'docs.openssl.org', 'registry.npmjs.org', 'www.w3.org']);
const PUBLIC_EMAILS = new Set(['noreply@8415wallet.com']);
const LOOPBACK_IPV4 = new Set(['127.0.0.1', '0.0.0.0', '255.255.255.255']);
const DOCUMENTATION_IPV4 = [/^192\.0\.2\.\d{1,3}$/, /^198\.51\.100\.\d{1,3}$/, /^203\.0\.113\.\d{1,3}$/, /^198\.1[89]\.\d{1,3}\.\d{1,3}$/];
const FILE_SUFFIX = /\.(?:md|mjs|cjs|js|ts|json|txt|html|css|svg|png|jpe?g|webp|ico|woff2?|ttf|sol|tar|tgz|gz|zip|service)$/i;

export function confidentialityRefusal(text) {
  for (const m of text.matchAll(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g)) {
    if (!PUBLIC_EMAILS.has(m[0].toLowerCase())) return 'PRIVATE_EMAIL';
  }
  for (const m of text.matchAll(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g)) {
    const value = m[0];
    if (LOOPBACK_IPV4.has(value) || DOCUMENTATION_IPV4.some((re) => re.test(value))) continue;
    return 'PRIVATE_IP';
  }
  for (const m of text.matchAll(/(?:[0-9a-fA-F]{0,4}:){3,}[0-9a-fA-F]{0,4}|::1\b/g)) {
    const value = m[0];
    if (value === '::1' || /^2001:db8:/i.test(value)) continue;
    return 'PRIVATE_IP';
  }
  // Dotted language identifiers such as block.timestamp are not host identities.
  // Only an actual URL authority or explicitly labelled host field is a binding.
  const hostReferences = [...text.matchAll(/\bhttps?:\/\/([a-z0-9.-]+)(?::[0-9]+)?/gi),
    ...text.matchAll(/\b(?:host(?:name)?|server|rpc endpoint)\s*[:=]\s*[\"']?((?:[a-z0-9-]+\.)+[a-z]{2,})/gi)];
  for (const m of hostReferences) {
    const value = m[1].toLowerCase();
    if (!PUBLIC_HOSTS.has(value)) return 'PRIVATE_HOST';
  }
  if (/(?:\/home\/|\/Users\/|\/etc\/|\/var\/|\/opt\/|\/srv\/|[A-Za-z]:\\)/.test(text)) return 'PRIVATE_PATH';
  if (/-----BEGIN [A-Z ]*PRIVATE KEY-----/.test(text)) return 'PRIVATE_KEY';
  if (/\b(?:store[_-]?key|smtp[_-]?password|password|secret|token|api[_-]?key)\s*[:=]\s*["'][^"'\n]{8,}["']/i.test(text)) return 'CREDENTIAL_VALUE';
  // An address shape alone does not establish privacy. Actual protected identities
  // are checked by the existing private scanner outside the delivery payload.
  return null;
}


const entryBytes=v=>Buffer.isBuffer(v)?v:Buffer.isBuffer(v?.bytes)?v.bytes:Buffer.from(v);
export const V2_DOCUMENT_SCHEMA=BASELINE.schema;
export const CANONICAL_PRD=BASELINE.canonical;
export const REVIEWED_BASELINE=BASELINE.reviewedBaseline;
export const V2_CLAUSES=BASELINE.clauses;
export const V2_APPLICABILITY_PATH='docs/V2-PRD-APPLICABILITY.md';
export const V2_CONTRACT_PATH='docs/V2-DOCUMENT-CONTRACT.json';
export const V2_DOCUMENT_PATHS=Object.freeze([V2_APPLICABILITY_PATH,V2_CONTRACT_PATH,'docs/V2-DELIVERY.md','docs/V2-PRD-COVERAGE.md','docs/V2-INSTALL.md']);
export const V2_UI_LEGAL_FILES=Object.freeze(['LICENSE','THIRD_PARTY_NOTICES.md','LICENSES/CC0-1.0.txt']);
export const MIXED_DOCUMENT_PATHS=Object.freeze([CANONICAL_PRD.path,'docs/BETA-DAPP-DELIVERY.md','docs/BETA-PRD-COVERAGE.md','AGENTS.md']);
export function documentDescriptor(entries){
 return {schema:V2_DOCUMENT_SCHEMA,canonical:{...CANONICAL_PRD},documents:V2_DOCUMENT_PATHS.map(path=>{const b=entryBytes(entries.get(path));return{path,bytes:b.length,sha256:hash(b)};})};
}
export function v2DocumentMap(entries){
 fail(entries instanceof Map,'ENTRIES_REQUIRED');
 return new Map(V2_DOCUMENT_PATHS.map(p=>{fail(entries.has(p),'MISSING_DOCUMENT_'+p);return[p,entryBytes(entries.get(p))];}));
}
export function verifyV2DocumentEntries(entries,{source,canonicalText}={}){
 fail(entries instanceof Map,'ENTRIES_REQUIRED');
 fail(stable([...entries.keys()].sort())===stable([...V2_DOCUMENT_PATHS].sort()),'EXACT_INVENTORY');
 const get=p=>entryBytes(entries.get(p));
 let contract;try{contract=JSON.parse(get(V2_CONTRACT_PATH).toString('utf8'));}catch{throw Error('V2_DOCUMENT_CONTRACT_PARSE');}
 fail(contract.schema===V2_DOCUMENT_SCHEMA&&contract.profile==='v2','SCHEMA');
 fail(stable(contract.canonical)===stable(CANONICAL_PRD),'CANONICAL_IDENTITY');
 fail(stable(contract.reviewedBaseline)===stable(REVIEWED_BASELINE),'REVIEWED_BASELINE');
 fail(contract.projection?.canonicalReplacement===false,'PROJECTION_KIND');
 fail(contract.source&&stable(Object.keys(contract.source).sort())===stable(['commit','dirty','tree'])&&git.test(contract.source.commit)&&git.test(contract.source.tree)&&typeof contract.source.dirty==='boolean','SOURCE_IDENTITY');
 if(source!==undefined)fail(stable(contract.source)===stable(source),'SOURCE_IDENTITY');
 fail(Array.isArray(contract.clauses)&&contract.clauses.length===V2_CLAUSES.length,'CLAUSE_COUNT');
 let at=0;
 contract.clauses.forEach((c,i)=>{
  const expected=V2_CLAUSES[i];
  fail(c.id===expected.id&&stable(c.source)===stable(expected.source)&&c.source.start===at,'CLAUSE_SPAN_'+expected.id);
  at=c.source.end;
 });
 fail(at===CANONICAL_PRD.bytes,'CLAUSE_COVERAGE');
 for(const p of V2_DOCUMENT_PATHS)fail(!confidentialityRefusal(get(p).toString('utf8')),'CONFIDENTIALITY_'+p);
 const projection=get(V2_APPLICABILITY_PATH).toString('utf8');
 const marks=[...projection.matchAll(/^<!-- v2-clause (c\d+) (included|projected|reference) -->\n/gm)];
 const emitted=V2_CLAUSES.filter(c=>c.disposition!=='excluded');
 fail(marks.length===emitted.length,'CLAUSE_MARKERS');
 marks.forEach((m,i)=>{
  const c=emitted[i],end=i+1<marks.length?marks[i+1].index:projection.length;
  const body=projection.slice(m.index+m[0].length,end).replace(/\n+$/,'');
  fail(m[1]===c.id&&m[2]===c.disposition,'CLAUSE_ORDER_'+c.id);
  fail(body.split('\n')[0]===c.heading,'CLAUSE_HEADING_'+c.id);
  for(const anchor of c.anchors)fail(body.includes(anchor),'CLAUSE_ANCHOR_'+c.id);
  fail(!linkedRefusal(body),'LINKED_CONTENT_'+c.id);
 });
 for(const expected of BASELINE.documents){
  const b=get(expected.path);
  fail(b.length===expected.bytes&&hash(b)===expected.sha256,expected.path===V2_APPLICABILITY_PATH?'REVIEWED_PROJECTION':'STATIC_DOCUMENT_'+expected.path);
 }
 const {source:actualSource,...normalized}=contract;
 fail(stable(normalized)===stable(BASELINE),'REVIEWED_CLAUSE_MAP');
 if(canonicalText!==undefined){
  const b=entryBytes(canonicalText);fail(b.length===CANONICAL_PRD.bytes&&hash(b)===CANONICAL_PRD.sha256,'CANONICAL_DRIFT');
 }
 return{profile:'v2',schema:V2_DOCUMENT_SCHEMA,canonical:{...CANONICAL_PRD},contract,documents:V2_DOCUMENT_PATHS.length,canonicalVerified:canonicalText!==undefined,projectionVerified:true,rederived:false};
}
export function verifyV2DocumentInventory(entries,{source,canonicalText}={}){
 fail(entries instanceof Map,'ENTRIES_REQUIRED');
 for(const [p,e]of entries){
  if(p.startsWith('docs/'))fail(V2_DOCUMENT_PATHS.includes(p),'MIXED_DOCUMENT_'+p);
  fail(!MIXED_DOCUMENT_PATHS.includes(p),'MIXED_DOCUMENT_'+p);
  const b=entryBytes(e);fail(b.length===0||hash(b)!==CANONICAL_PRD.sha256,'CANONICAL_PAYLOAD_'+p);
 }
 const documents=v2DocumentMap(entries);
 return{result:verifyV2DocumentEntries(documents,{source,canonicalText}),documents,descriptor:documentDescriptor(documents)};
}
