/** Public V2 install kit: exact UI+auth closure; no other-profile or full-source payload. */
import assert from 'node:assert/strict';
import {lstatSync,realpathSync,mkdirSync,mkdtempSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {tmpdir} from 'node:os';
import {readDeliveryArchive} from './archive-v2.mjs';
import {sha256,safePath,verifyAuthDirectory} from './verify-auth-v2.mjs';
import {resolveReleaseProfile} from '../../web/release-profile-v2.mjs';
import {CANONICAL_PRD,V2_APPLICABILITY_PATH,V2_DOCUMENT_PATHS,V2_UI_LEGAL_FILES,verifyV2DocumentInventory} from './v2-document-contract.mjs';
import {verifyNoEmbeddedArchives} from './v2-nested-archive.mjs';
export {sha256};
export const DELIVERY_SCHEMA='8415wallet-public-v2-install/1';
/** Source-tracked tools copied into the kit; the document set is generated. */
export const DELIVERY_TOOL_FILES=Object.freeze(['deploy/dapp-v2/install.mjs','deploy/tenant-profile-policy.mjs','scripts/package/verify-v2-delivery.mjs','scripts/package/archive-v2.mjs','scripts/package/verify-auth-v2.mjs','scripts/package/v2-document-contract.mjs','scripts/package/v2-nested-archive.mjs','web/image-policy.mjs','web/release-profile-v2.mjs','web/tenant-password-routing.mjs','web/wallet-entry.mjs','web/tenant-path.mjs','config/releases/v2.json','LICENSE','THIRD_PARTY_NOTICES.md','LICENSES/CC0-1.0.txt','scripts/package/verify-v2-production.mjs','scripts/package/v2-production-documents.mjs','scripts/package/v2-public-receipt.mjs','scripts/package/v2-production-isolation.mjs']);
export const DELIVERY_FILES=Object.freeze([...DELIVERY_TOOL_FILES,...V2_DOCUMENT_PATHS]);
const check=(ok,code)=>{if(!ok)throw Error('V2_DELIVERY_'+code);};
const hash=/^[a-f0-9]{64}$/,tree=/^[a-f0-9]{40}$/;
const get=(entries,path)=>{check(entries.has(path),'MISSING_'+path);return entries.get(path).bytes;};
const parsed=(entries,path)=>JSON.parse(get(entries,path).toString('utf8'));
const hashes=entries=>Object.fromEntries([...entries].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([p,e])=>[p,sha256(e.bytes)]));
const sums=entries=>[...entries].filter(([p])=>p!=='SHA256SUMS').sort(([a],[b])=>a<b?-1:a>b?1:0).map(([p,e])=>`${sha256(e.bytes)}  ${p}`).join('\n')+'\n';
export function isPublicFile(path){return safePath(path)&&/^(?:web\/|dist\/browser\/)/.test(path)&&!path.split('/').some(p=>p.startsWith('.'))&&(/\.(?:html|mjs|js|css|json|svg|png|jpg|jpeg|webp|ico|woff|woff2|ttf)$/.test(path)||['web/assets/license-dm-sans.txt','dist/browser/vendor/ETHERS-LICENSE.md','web/legal/LICENSE','web/legal/THIRD_PARTY_NOTICES.md','web/legal/LICENSES/CC0-1.0.txt'].includes(path));}
export function verifyDeliveryArchive(archive,{expectedSha256,expectedTree,canonicalText}={}){
 check(hash.test(expectedSha256??'')&&tree.test(expectedTree??''),'EXTERNAL_PINS_REQUIRED');
 const entries=readDeliveryArchive(archive,expectedSha256),release=parsed(entries,'DELIVERY.json');
 check(release.schema===DELIVERY_SCHEMA&&release.profile==='v2'&&release.source?.tree===expectedTree,'IDENTITY_REFUSED');
 assert.deepEqual(Object.keys(release.source).sort(),['commit','dirty','tree']);assert.deepEqual(Object.keys(release.artifacts).sort(),['auth','v2']);
 check(get(entries,'SHA256SUMS').toString()===sums(entries),'SUMS_MISMATCH');
 const expected=new Set([...DELIVERY_FILES,'DELIVERY.json','SHA256SUMS']),nested=[];
 for(const item of Object.values(release.artifacts)){check(item&&safePath(item.artifact)&&!item.artifact.includes('/')&&hash.test(item.sha256),'ARTIFACT_REFUSED');expected.add('artifacts/'+item.artifact);nested.push('artifacts/'+item.artifact);check(sha256(get(entries,'artifacts/'+item.artifact))===item.sha256,'ARTIFACT_HASH_MISMATCH');}
 assert.deepEqual([...entries.keys()].sort(),[...expected].sort(),'V2_DELIVERY_EXACT_INVENTORY');
 assert.deepEqual(release.files,Object.fromEntries(DELIVERY_FILES.map(p=>[p,sha256(get(entries,p))])),'V2_DELIVERY_TOOL_HASHES');
 const kitDocuments=verifyV2DocumentInventory(entries,{source:release.source,canonicalText});
 assert.deepEqual(release.documents,kitDocuments.descriptor,'V2_DELIVERY_DOCUMENT_DESCRIPTOR');
 verifyNoEmbeddedArchives(entries,{allowed:nested});
 const ui=readDeliveryArchive(get(entries,'artifacts/'+release.artifacts.v2.artifact),release.artifacts.v2.sha256),uiRelease=parsed(ui,'RELEASE.json');
 check(uiRelease.schema==='8415wallet-public-v2/1'&&uiRelease.profile==='v2'&&uiRelease.source.tree===expectedTree,'UI_IDENTITY_REFUSED');
 assert.deepEqual(Object.keys(uiRelease.source).sort(),['commit','dirty','tree']);check(!Object.hasOwn(uiRelease,'sourceArchive'),'FULL_SOURCE_REFUSED');
 const profile=resolveReleaseProfile(parsed(ui,'web/release-config.json'));check(profile.id==='v2'&&!profile.features.linkedResponsibilities,'UI_PROFILE_REFUSED');
 assert.deepEqual(profile.features,uiRelease.features);check(uiRelease.build.configSha256===sha256(get(ui,'web/release-config.json')),'UI_CONFIG_MISMATCH');
 const uiDocuments=verifyV2DocumentInventory(ui,{source:uiRelease.source,canonicalText});
 assert.deepEqual(uiRelease.documents,uiDocuments.descriptor,'V2_DELIVERY_UI_DOCUMENT_DESCRIPTOR');
 for(const path of V2_DOCUMENT_PATHS)check(get(ui,path).equals(get(entries,path)),'V2_DELIVERY_DOCUMENT_SET_MISMATCH');
 check(uiRelease.prd.file===V2_APPLICABILITY_PATH&&uiRelease.prd.canonicalSha256===CANONICAL_PRD.sha256,'UI_PRD_PROVENANCE_REFUSED');
 check(sha256(get(ui,uiRelease.prd.file))===uiRelease.prd.sha256,'UI_PRD_MISMATCH');
 check(get(ui,'SHA256SUMS').toString()===sums(ui),'UI_SUMS_MISMATCH');
 const uiAllowed=new Set(['RELEASE.json','SHA256SUMS',...V2_UI_LEGAL_FILES,...V2_DOCUMENT_PATHS,...Object.keys(uiRelease.codeIsolation.runtimeFiles)]);
 assert.deepEqual([...ui.keys()].sort(),[...uiAllowed].sort(),'V2_DELIVERY_UI_EXACT_INVENTORY');
 assert.deepEqual(uiRelease.source,release.source,'V2_DELIVERY_UI_SOURCE_IDENTITY');
 const runtime=new Map([...ui].filter(([p])=>p.startsWith('web/')||p.startsWith('dist/browser/')));check([...runtime.keys()].every(isPublicFile)&&runtime.has('web/index.html'),'UI_RUNTIME_REFUSED');
 check(![...ui.keys()].some(p=>/^dist\/browser\/controls\/|^dist\/browser\/sdk\/linked\.|^dist\/browser\/wallet\/(?:linkedChainView|renderLinkedChain)\.|\.(?:tgz|tar\.gz|zip)$/.test(p)),'V3_UI_REFUSED');
 assert.deepEqual(hashes(runtime),uiRelease.codeIsolation.runtimeFiles,'V2_DELIVERY_UI_RUNTIME_HASHES');
 verifyNoEmbeddedArchives(ui);
 const authEntries=readDeliveryArchive(get(entries,'artifacts/'+release.artifacts.auth.artifact),release.artifacts.auth.sha256);
 verifyNoEmbeddedArchives(authEntries);
 const temp=mkdtempSync(join(tmpdir(),'v2-install-verify-'));
 try{
  for(const [p,e]of authEntries){mkdirSync(dirname(join(temp,p)),{recursive:true,mode:0o755});writeFileSync(join(temp,p),e.bytes,{flag:'wx',mode:0o644});}
  const auth=verifyAuthDirectory(temp,{expectedTree});assert.deepEqual({commit:auth.source.commit,tree:auth.source.tree,dirty:auth.source.dirty},release.source);
  // The auth runtime keeps the actual canonical requirements digest; the UI
  // digest describes the projection. They are provenance-linked, not equal.
  check(auth.source.prdSha256===CANONICAL_PRD.sha256,'AUTH_CANONICAL_PROVENANCE_REFUSED');
  check(kitDocuments.descriptor.canonical.sha256===auth.source.prdSha256&&uiDocuments.descriptor.canonical.sha256===auth.source.prdSha256,'PRD_PROVENANCE_MISMATCH');
  check(auth.source.prdSha256!==uiRelease.prd.sha256,'PRD_PROJECTION_NOT_CANONICAL');
  return {release,entries,dapps:{v2:{release:uiRelease,runtime}},auth,authRuntime:authEntries,documents:kitDocuments.descriptor,sha256:expectedSha256};
 }finally{rmSync(temp,{recursive:true,force:true});}
}

export function extractDelivery(result, destination) {
  destination = resolve(destination);
  let parent = dirname(destination);
  while (true) {
    const stat = lstatSync(parent), uid = process.getuid?.();
    check(stat.isDirectory() && !stat.isSymbolicLink() && realpathSync(parent) === parent
      && (uid === undefined || stat.uid === uid || stat.uid === 0)
      && (!(stat.mode & 0o022) || (stat.uid === 0 && (stat.mode & 0o1000))), 'EXTRACT_PARENT_REFUSED');
    if (dirname(parent) === parent) break; parent = dirname(parent);
  }
  mkdirSync(destination, { mode: 0o700 }); // An existing target is deliberately refused.
  try {
    for (const [path, entry] of [...result.entries, ...[...result.authRuntime].map(([path, entry]) => [`runtime/auth/${path}`, entry])]) {
      mkdirSync(dirname(join(destination, path)), { recursive: true, mode: 0o755 });
      writeFileSync(join(destination, path), entry.bytes, { flag: 'wx', mode: 0o644 });
    }
  } catch (error) { rmSync(destination, { recursive: true, force: true }); throw error; }
  return destination;
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [command,archive,expectedSha256,expectedTree,destination,...extra]=process.argv.slice(2);
 check(['verify','extract'].includes(command)&&archive&&expectedSha256&&expectedTree&&extra.length===0&&(command==='extract'?destination!==undefined:destination===undefined),'ARGUMENT_REFUSED');
 const result=verifyDeliveryArchive(resolve(archive),{expectedSha256,expectedTree});
 if(command==='extract')extractDelivery(result,resolve(destination));
 console.log(JSON.stringify({profile:'v2',sourceTree:expectedTree,sha256:expectedSha256,verified:true,extracted:command==='extract',installed:false}));
}
