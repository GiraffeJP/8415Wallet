/** Private deploy-time tenant→profile policy. The file lives outside the repository and the public bundle. */
import { lstatSync, readFileSync } from 'node:fs';
import { isAbsolute, resolve } from 'node:path';

export function loadTenantProfilePolicy(path) {
  try {
    if (typeof path !== 'string' || !isAbsolute(path) || path !== resolve(path)) throw new Error();
    const stat = lstatSync(path);
    if (!stat.isFile() || stat.size > 65536) throw new Error();
    const data = JSON.parse(readFileSync(path, 'utf8'));
    if (typeof data !== 'object' || data === null || Array.isArray(data)) throw new Error();
    const entries = Object.entries(data);
    if (entries.length > 256) throw new Error();
    const policy = Object.create(null);
    for (const [key, value] of entries) {
      if (!/^[a-z][a-z0-9-]{0,47}$/.test(key) || (value !== 'v2' && value !== 'v3')) throw new Error();
      policy[key] = value;
    }
    return Object.freeze(policy);
  } catch {
    throw new Error('TENANT_PROFILE_POLICY_REFUSED');
  }
}

export function enforceTenantProfilePolicy(policy, tenant, profile) {
  if (policy === null || policy === undefined) return;
  if (Object.hasOwn(policy, tenant) && policy[tenant] !== profile) throw new Error('RELEASE_TENANT_PROFILE_POLICY_REFUSED');
}
