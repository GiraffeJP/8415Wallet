# 8415wallet V2 PRD coverage

## How to read this record

Coverage is expressed against the clause catalog in `V2-DOCUMENT-CONTRACT.json`. Each clause id maps to an exact canonical byte span with a disposition and reason; the projected requirement text is in `V2-PRD-APPLICABILITY.md`. A coverage row is a traceability reference, not a statement that a test ran for a particular artifact. Actual results belong to the source-bound CI and delivery records for the exact candidate.

## Clause applicability

| Clause | Canonical scope | V2 disposition |
| --- | --- | --- |
| c0 | Release, default-value, interface, platform and market-data decisions | projected, applicable |
| c1 | Preserved v2.x revision history | excluded as history; superseded narrative, current section 2 included |
| c2 | Product definition, identity, login, password rule | projected, applicable |
| c3 | Multichain compatibility MC-01 to MC-08 | projected, applicable |
| c4 | Section 1 design principle | included |
| c5 | Section 2 core architecture | included |
| c6 | Section 3 data model | projected, applicable |
| c7 | Section 4 core features | projected, applicable |
| c8 | Section 5 application patterns | projected, applicable |
| c9 | Sections 6.1 to 6.5.1 security requirements | projected, applicable |
| c10 | Section 6.6 implementation and acceptance evidence | projected to V2 evidence-level requirements |
| c11 | Section 7 development stages 0 to 5 | included |
| c12 | Section 8 standalone definition of done | projected, applicable |
| c13 | Out-of-profile source range | excluded; traceability reference only |
| c14 | Sections 10.1 to 10.8 UI/API requirements | projected, applicable |
| c15 | Section 10.9 staged Web and platform delivery | projected, applicable |
| c16 | Appendix A corrections | reference, retained |
| c17 | Appendix B discussion rationale | reference, retained |

## Requirement families retained for V2

| Family | Clauses | Retained requirements |
| --- | --- | --- |
| Authentication and login | c2, c9, c14 | Verified login before asset/history display; password, authenticator TOTP, wallet-control proof and hardware CA routes; no email-code login; concurrent methods with at least one independent method; session, origin, tenant, account and chain binding |
| Password and reset policy | c2, c9 | Password rule 8: at least 8 JavaScript characters, at most 1024 UTF-8 bytes, at least two of four classes, enforced only when set or changed; security answers 4 to 512 bytes; OTP-only test reset to the previously verified email; production two-factor rules and audit before real assets |
| OTP, registration and recovery | c2, c9, c14 | Registration email ownership plus wallet-control proof; reserved-email OTP and security answer as additional reset checks; exact-change combined independent verification; one-use, purpose-bound, short-lived proofs |
| Owner settings and agent authority | c9, c14 | Default ON for agent, asset tree, operations and per-operation verification; human-only settings saves with exact-revision secondary authentication; recursive asset scope and inherited/overridden operations; persistent owner-verified OFF without repeated prompts; machine-enforced scope, nonce, budget and reconciliation |
| Assets, funds and valuation | c7, c14 | Per-currency total, unreleased escrow and available funds; exact base-unit arithmetic; indicative USD valuation and commodity reference quotes with source, unit, coverage and freshness provenance; no conversion, Swap or Bridge authority |
| History and observation | c7, c9, c14 | Append-only entry and settlement history; privacy-safe holder positions; approved verifier and actual observer kept distinct; versioned observation envelope; refresh, stale, unavailable and reorg states; frozen completed records |
| Multichain | c3 | Authoritative network/capability model, provider verification, per-chain isolation, chain-bound execution, UI/agent parity, family boundaries, evidence and release integrity |
| Platform delivery | c15 | Web trial first, then Android, iOS, Windows and macOS as separate deliveries with protected storage, upgrade persistence and their own acceptance records |
| Acceptance and confidentiality | c10, c12, c14 | Separate evidence levels; NOT_RUN for absent execution; V2-only release sequence; no private identities in public artifacts; profile-inapplicable cases marked N/A |

## Explicitly not applicable to V2

Only applicable standalone clauses form the V2 requirement and acceptance scope. Excluded source ranges are traceability metadata, not a feature list or an additional acceptance prerequisite. The retained legacy single-trade clearing pattern remains applicable.

## Evidence levels

Source review, synthetic deterministic tests, local contract execution, real-network reads, genuine device journeys and deployed acceptance are distinct. Package verification and this coverage record establish none of them. Record each actual result against the exact source commit, content tree, canonical requirements digest and package hashes.
