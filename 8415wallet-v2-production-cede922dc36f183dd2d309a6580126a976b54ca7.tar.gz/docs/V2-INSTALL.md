# 8415wallet V2 install and usage

## Scope

This kit contains the V2 browser UI, V2 auth/API runtime and separate protected installers. Verification and extraction never install, activate, provision or deploy anything. The recipient performs any later installation under its own authorization.

## Prerequisites

Node 22.18.0 or newer on Linux, GNU tar and gzip. Runtime production dependencies are bundled; no TypeScript compiler, development source checkout or test directory is needed to verify or install. Hardware-CA verification additionally requires the recipient's authorized OpenSSL 3 and real device integration; this kit does not provision them. Ordinary asset task/sale integration uses a separately authorized external provider composition; a missing provider is unavailable, never a successful sale.

## Verify before writing anything

1. Obtain the distribution SHA-256, content-tree pin and simulation-receipt pin from the independent handoff. These out-of-band pins are the trust root; the receipt itself is a source-bound CI record, not proof of real network results.
2. Run `node scripts/package/verify-v2-production.mjs verify <archive> <sha256> <tree> <receipt-sha256>`. Add `--expected-commit <commit>` to also pin the source commit.
3. To materialize a verified payload into a new protected directory, run `node scripts/package/verify-v2-production.mjs extract <archive> <sha256> <tree> <receipt-sha256> <new-directory>`. An existing target is refused.

The verifier enforces the exact production inventory, nested artifact pins, UI runtime closure, auth runtime inventory and import closure, immutable requirement projection, authored production document bytes, public receipt whitelist, source/receipt pins, and refusal of traversal, links, duplicate paths, private material and embedded archives except the two pinned runtime artifacts.

## Installation preparation

The UI installer is `deploy/dapp-v2/install.mjs` with `config`, `plan`, `install`, `upgrade` and `rollback` commands; only `--profile v2` is accepted. Supplying `--receipt-sha256 <simulation-receipt-pin>` selects the explicit production mode, which verifies the production schema, documents and public receipt before any protected write; without it the original offline-candidate verification is used unchanged. The auth installer is inside the auth artifact at `deploy/auth-runtime-v2/install.mjs` and requires independent `--expected-tree` and `--expected-manifest-sha256` pins. Both retain explicit tenant, origin, target and pin requirements and never alter services.

The operator supplies the exact existing tenant, expected origin, socket and authoritative encrypted store bindings. Do not create an empty replacement store, overwrite credentials or journals, silently migrate an older mixed-profile runtime, change ports, provision credentials or activate services because verification succeeded. Unknown outcomes must be reconciled, never cleared. Downgrades and incompatible prior profiles fail closed.

## Usage after an authorized installation

Serve the complete UI tree with its `web/` and `dist/browser/` layout intact at the exact configured entry path. The public entry stays open; assets, balances, holdings, history and recovery journals require a verified wallet login and are re-locked on reload, logout, expiry and identity changes. Human management and authorization stay in the Web UI; agents use the authenticated API only.

## Evidence boundaries

The attached public receipt records controlled Linux simulation validation only. It does not establish a security audit, live deployment, real mail delivery, hardware-token success, physical-browser acceptance or on-chain acceptance. No new authority for transactions, credentials, configuration changes, deployment or notifications is supplied here.

## Standalone Pending read source

V2 includes a separate read-only Pending interface in the native read view and in each NFT detail. The NFT identity comes from the selected validated NFT. Enter the exact sequence reference supplied by the configured source; a register ID, watchtower feed or token address is never guessed to be a sequence reference. Missing or unsupported source data stays unavailable.

Server composition may pass `standaloneProgressSource` to the shipped V2 runtime factory. This is a code-owned capability, not an HTTP parameter, module path or credential selected by JSON. Its `8415-v2-standalone-progress-source/1` descriptor has captured source/capability IDs and versions plus `readObservation` and `readMilestone` callbacks. The first supplies an exact principal/asset/sequence/occurrence-bound complete observation and historical observations; the second independently returns the matching canonical immutable observation or explicit unavailable/revoked/reorged status for the requested block, revision and digest. It must read its own trusted source history and lifecycle state; echoing the request, returning a Boolean or assigning a claimed verified label is not source validation. The recipient supplies this existing lawful source composition; the artifact invents no network endpoint, watchtower signing key, financial authority or equivalent ERC-8415 RPC.

The runtime validates complete coverage, lossless positions, exact bindings, source identity, revision high-water marks, full canonical observations and store CAS before saving. It preserves source-bound forward and coordinated-return milestones across restart, and reports invalidated source evidence as unavailable while retaining the durable record. Return DONE requires the source-bound owner and holder at the user return boundary plus verified NFT return and fund-refund evidence. Funds and return evidence remain distinct; the supplied source remains responsible for its underlying financial provenance. A completed forward observation and a later return observation expose their own block references. Neither read operation authorizes signing, sending, repayment, retry or budget release. These are observations at their actual validation point, not guarantees about unobserved future chain or source state.
