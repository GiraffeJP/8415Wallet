/** Fixed deployment routing only. A path is neither tenant discovery nor authority. */
import { walletName } from './wallet-entry.mjs';
const refuse = () => { throw Error('TENANT_PATH_BINDING_REFUSED'); };
export function tenantBasePath(tenant, basePath = '') {
  if (basePath === '') return '';
  if (!walletName(tenant) || ['v2', 'v3'].includes(tenant) || basePath !== `/${tenant}`) refuse();
  return basePath;
}
export function authRequestPath(tenant, basePath, operation) {
  tenantBasePath(tenant, basePath);
  if (typeof operation !== 'string' || !/^[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*$/.test(operation)) refuse();
  return `${basePath}/auth/${operation}`;
}
export function authOperation(tenant, basePath, rawPath) {
  tenantBasePath(tenant, basePath);
  const prefix = `${basePath}/auth/`;
  if (typeof rawPath !== 'string' || !rawPath.startsWith(prefix)) refuse();
  const operation = rawPath.slice(prefix.length);
  if (authRequestPath(tenant, basePath, operation) !== rawPath) refuse();
  return operation;
}
export function tenantClientOptions(profile, location = globalThis.location) {
  const configured = profile?.deployment?.url;
  if (!configured) return {};
  const expected = new URL(configured);
  if (expected.pathname.endsWith('/web/index.html')) return {};
  const basePath = tenantBasePath(profile.tenant.id, expected.pathname);
  const actual = new URL(location.href);
  if (expected.origin !== actual.origin || actual.pathname !== basePath || actual.search) refuse();
  return { basePath, origin: expected.origin };
}
/** Journal migration is deliberately not implemented by URL routing. Never open
 * a fresh empty journal that hides an existing UNKNOWN operation.
 *
 * EXACT STORAGE-KEY DERIVATION (byte for byte, no other transformation):
 *   legacy journal (module served at /web/..., /v2/web/... or /v3/web/...):
 *     IndexedDB database name = <name>            (unchanged)
 *     IndexedDB record key    = <key>             (unchanged)
 *     localStorage probe key  = <key>             (unchanged)
 *   FRESH isolated path tenant <t> (module served at /<t>/web/browser-journal-store.mjs):
 *     IndexedDB database name = '8415tenant:' + <t> + ':' + <name>
 *     IndexedDB record key    = '8415tenant:' + <t> + ':' + <key>
 *     localStorage probe key  = '8415tenant:' + <t> + ':' + <key>
 * The prefix is a non-empty constant, so a namespaced string can never equal the
 * legacy string: a fresh tenant can neither open, read, shadow nor hide the
 * default/v2/v3 journal, and legacy strings are never rewritten. An already
 * namespaced name/key (double prefix) is refused, never reused or re-prefixed.
 */
export const TENANT_JOURNAL_PREFIX = '8415tenant:';
const journalRefusal = () => { throw Error('CONTROL_TENANT_JOURNAL_MIGRATION_REQUIRED'); };
/** Namespace of a fresh isolated path tenant. Reserved/legacy ids are refused. */
export function tenantJournalNamespace(tenant) {
  if (!walletName(tenant) || ['default', 'v2', 'v3'].includes(tenant)) journalRefusal();
  return `${TENANT_JOURNAL_PREFIX}${tenant}:`;
}
/** Prefix one legacy storage string; a collision with the legacy key refuses. */
export function tenantJournalStorageKey(value, tenant) {
  const prefix = tenantJournalNamespace(tenant);
  if (typeof value !== 'string' || !value || value.startsWith(TENANT_JOURNAL_PREFIX) ||
      `${prefix}${value}` === value) throw Error('CONTROL_TENANT_JOURNAL_COLLISION_REFUSED');
  return `${prefix}${value}`;
}
/** The only way a path tenant module may run: a fresh namespace derived from its
 * own served URL. Returns null for the legacy default/v2/v3 module locations. */
export function journalNamespaceForModule(moduleUrl) {
  const url = new URL(moduleUrl);
  if (url.protocol === 'file:') return null; // Offline source tests, not a served origin.
  const match = url.pathname.match(/^\/([a-z][a-z0-9-]{0,47})\/web\/browser-journal-store\.mjs$/);
  if (!match || ['v2', 'v3'].includes(match[1])) return null;
  tenantJournalNamespace(match[1]);
  return Object.freeze({ tenant: match[1], fresh: true });
}
/** Without an explicit matching fresh namespace the path tenant stays refused. */
export function requireLegacyJournalLocation(moduleUrl, namespace = null) {
  const url = new URL(moduleUrl);
  if (url.protocol === 'file:') return; // Offline source tests, not a served origin.
  const match = url.pathname.match(/^\/([a-z][a-z0-9-]{0,47})\/web\/browser-journal-store\.mjs$/);
  if (!match || ['v2', 'v3'].includes(match[1])) return;
  if (!namespace || namespace.fresh !== true || namespace.tenant !== match[1]) journalRefusal();
  tenantJournalNamespace(namespace.tenant);
}
